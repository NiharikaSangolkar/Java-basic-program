package demo;

public class Students {
	 int total;
	 double percentage;
	public  void student_details( String name, int rollno,int sub1,int sub2)
	{
		 total=sub1+sub2;
		 percentage=(total/2);
		System.out.println("student name is: " +name );
		System.out.println("student roll no is: " +rollno);
		System.out.println("student subject1 mark : " +sub1);
		System.out.println("student subject2 mark : " +sub2);
		System.out.println("student total marks : " +total);
		System.out.println("student percentage mark : " +percentage);
		
		
	}
	public static void main(String [] args)
	{
		Students st=new Students();
		st.student_details("Ram Kapoor", 1, 89, 90);
		//System.out.println();//
		st.student_details("Meera Khan", 2, 50, 60);
		st.student_details("Joe Doe", 3, 80, 76);
		System.out.println();
		
	}

}
