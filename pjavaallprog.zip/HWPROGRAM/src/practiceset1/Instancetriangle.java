package practiceset1;

public class Instancetriangle {
	int br,h;
    int a;
	int b;
	int c;
	int area,per;
	
	public void details(int p,int q, int r, int s, int t)
	{
		br=p;
		h=q;
		a=r;
		b=s;
		c=t;
		
	}
	public void calculate()
	{
		area=(br*h)/2;
		per=(a+b+c);
	
	}
	public static void main(String[]args)
	{
		Instancetriangle t=new Instancetriangle();
		t.details(2,4,2,2,2);
		t.calculate();
	
		
	}
	/*public  static void main(String[]args)
	{
		
	}*/

}
