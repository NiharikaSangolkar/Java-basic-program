package practiceset1;
import java.util.Scanner;
public class Stringtest1 {
	public static void main(String[]args) {
	Scanner sc =new Scanner(System.in);
	System.out.println("enter string1:");
	String n1=sc.next();
	System.out.println("enter string2:");
	String n2=sc.next();
	System.out.println(n1+n2);
	
      
	

	
	}
	

}
