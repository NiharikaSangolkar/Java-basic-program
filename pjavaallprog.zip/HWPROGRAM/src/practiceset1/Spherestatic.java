/* vol=pi*r*r*r area=pi*4*r*r; 
   area=4*pi*r*r */
package practiceset1;

public class Spherestatic {
	static int r=3;
	static double pi=3.14;
	public static void vol()
	{
		double vol=pi*r*r*r;
		System.out.println(vol);
	}
	public static void area()
	{
		double area=4*pi*r*r;
		System.out.println(area);
	}
	public static void main(String [] args)
	{   area();
		vol();
	}
	
	
			

}
