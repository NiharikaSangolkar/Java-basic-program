/* 2.WAP TO CALCULATE AREA AND 
 OF A TRIANGLE
   formula area of triangle= 0.5*br*h ;  perimeter of triangle=a+b+c */
package practiceset1;

public class Areaperitriangle {
	public static void main(String arr[])
	{ 
		int br=4;
		int h=4;
		int a=2;
		int b=3;
		int c=4;
		int area=(br*h)/2;
		int peri=a+b+c;
		
		System.out.println(area);
		System.out.println(peri);
		
		
	
	}

}
