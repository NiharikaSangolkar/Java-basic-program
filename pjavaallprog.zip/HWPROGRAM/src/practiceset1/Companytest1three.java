package practiceset1;

import java.util.Scanner;

public class Companytest1three {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name:");
		String name=sc.next();
		System.out.println("enter roll no:");
		int roll=sc.nextInt();
		System.out.println("enter field of interset:");
		String field=sc.next();
		
System.out.println(("Hey,my name is "+name+" and my roll no is "+roll+". My field of interest is "+field));
		
		
		
		
	}

}
