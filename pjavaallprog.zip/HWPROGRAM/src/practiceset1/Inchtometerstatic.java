package practiceset1;

public class Inchtometerstatic {
	static int I=1;
	public static void meter()
	{
		double meter=(I/39.37);
		System.out.println(meter);
				
	}
	public static void main(String[] args)
	{
		meter();
	}

}
