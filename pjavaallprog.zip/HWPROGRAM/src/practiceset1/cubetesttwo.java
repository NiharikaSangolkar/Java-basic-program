package practiceset1;

import java.util.Scanner;

public class cubetesttwo {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter side:");
		int a=sc.nextInt();
		int v=a*a*a;
		int A=6*a*2;
		int p=6*a;
		System.out.println("vol="+v);
		System.out.println("area="+A);
		System.out.println("peri="+p);
		
		
		
		
		
	}

}
