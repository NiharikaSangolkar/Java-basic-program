package practiceset1;

import java.util.Scanner;

public class Genderswitch {
public static void main(String[]args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("ender your gender: ");
	
	char gender= sc.next().charAt(0);

	switch(gender)
	{
	case 'f':System.out.println("gender is female");
	break;
	case 'm': System.out.println("gender is male");
	break;
	default:System.out.println("invalid");
	}
}
}
