/* WAP TO CALCULATE AREA AND PERIMETER OF A SQUARE
    area=side*side and premiter=4*side */
package practiceset1;

public class Areaprimetersquare {
	public static void main(String arr[])
	 {
		 int side=5;
		 int area=side*side;
		 int perimeter=4*side;
	
	System.out.println(area);
	System.out.println(perimeter);
	/*System.out.println(side);*/
	
	

}

}
