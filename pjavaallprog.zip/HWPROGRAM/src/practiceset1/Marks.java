/* 4)if the marks of Robert in three subjects are 78,45 and 62 respectively 
 * (each out of 100 ), write a program to calculate his total marks and 
 * percentage marks.
*/
package practiceset1;

public class Marks {
	public static void main(String arr[])
	{
		int s1=78;
		int s2=45;
		int s3=62;
		int T=s1+s2+s3;
		int P=T/3;
		System.out.println(T);
		System.out.println(P);
	}

}
