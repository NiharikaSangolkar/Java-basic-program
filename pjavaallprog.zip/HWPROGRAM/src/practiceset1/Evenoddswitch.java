package practiceset1;

import java.util.Scanner;

public class Evenoddswitch {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the num:");
		int num=sc.nextInt();
		
		
		switch(num%2) {
		
		case 0: System.out.println("number is even:" +num);
		 
		break;
		case 1:System.out.println("number is odd:" +num);
		break;
		
		}
		
	}

}
