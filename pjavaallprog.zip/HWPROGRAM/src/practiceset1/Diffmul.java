/* WAP to print the difference and product of the numbers 45 and 32.*/
package practiceset1;

public class Diffmul {
	public static void main(String arr[])
	{
		int a=45;
		int b=32;
		int diff=a-b;
		int mul=a*b;
           		
		System.out.println(diff);
		System.out.println(mul);
		
	}

}
