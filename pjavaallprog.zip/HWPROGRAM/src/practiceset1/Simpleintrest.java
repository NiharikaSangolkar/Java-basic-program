/*5.WAP TO CALCULATE SIMPLE INTEREST
S.I=(P*R*T)/100
Where,
p is principal amount
r is the rate of interest
t is the time taken*/
package practiceset1;

public class Simpleintrest {
	public static void main(String arr[])
	{
		int P=20;
		int R=30;
		int T=40;
		int SI=(P*R*T)/100;
		System.out.println(SI);
		
	}

}
