package practiceset1;

import java.util.Scanner;

public class Calculatorswitch {
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your choice: 1:add 2:sub 3:mul 4:div 5:mod");
		int ch=sc.nextInt();
		System.out.println("enter num1:");
		int num1=sc.nextInt();
		System.out.println("enter num2:");
		int num2=sc.nextInt();
		//int num1=4;
		//int num2=6;
		
		switch(ch) {
		case 1:System.out.println("addition is :"+(num1+num2));
		break;
		case 2:System.out.println("substraction is :"+(num1-num2));
		break;
		case 3:System.out.println("multiplication is :"+(num1*num2));
		break;
		case 4:System.out.println("division is :"+(num1/num2));
		break;
		case 5:System.out.println("mod is :"+(num1%num2));
		break;
		default:System.out.println("wrong choice");
		}
	}

}
