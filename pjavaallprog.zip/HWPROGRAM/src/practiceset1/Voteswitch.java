package practiceset1;
import java.util.Scanner;
public class Voteswitch {
	public static void main(String[]args)
	{
		//Scanner sc=new Scanner(System.in);
		//System.out.println("enter your age:");
		int age=18;
		switch(age)
		{
		case(16):System.out.println("your not eligible.");
		break;
		case(18):System.out.println("your are eligible.");
		break;
		
	}

}
}
