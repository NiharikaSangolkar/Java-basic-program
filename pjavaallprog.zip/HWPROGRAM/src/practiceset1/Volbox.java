/* 5.WAP TO CALCULATE VOLUME OF A BOX(L*B*H)*/
package practiceset1;

public class Volbox {
	public static void main(String arr[])
	{
		int L=4;
		int B=6;
		int H=8;
		int volbox=L*B*H;
		
		System.out.println(volbox);
	}

}
