/* 11)Write a Java program to print 'Hello' on screen and then print your
 name on a separate line */
package practiceset1;

public class Helloname {
	public static void main(String arr[])
	{
		System.out.println("Hello");
		System.out.println("Niharika");
		
	}

}
