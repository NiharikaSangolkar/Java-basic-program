/*12)Write a Java program that reads a number in inches, converts it to meters
 One inch is 0.0254 meter.  formula meter=( 1/39.37)*/
package practiceset1;

public class Conincmeter {
	public static void main (String arr[])
	{
		int inch=1;
		double meter=(inch/39.37);
		System.out.println(meter);
	}

}
