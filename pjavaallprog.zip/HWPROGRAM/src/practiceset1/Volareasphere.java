/* practiceset1_2
 * 1)Write a program to calculate the  volume,and Area of a Sphere
Volume:πr³  area = 4πr² */
package practiceset1;

public class Volareasphere {
	public static void main(String arr[])
	{
		int r=3;
		double pi=3.14;
		
		double vol=pi*r*r*r;
		double area=4*pi*r*r;
		System.out.println(vol);
		System.out.println(area);
	}

}
