/*3.Write a program to print area and perimeter of a Rectangle 
 * Area of Rectangle = Length X Width 
 * Perimeter of Rectangle = 2 X(Length + Width) 
*/
package practiceset1;

public class Arperirectangle {
	public static void main(String arr[])
	{
		int length=2;
		int width=6;
		int area=length*width;
		int peri=2*(length+width);
		System.out.println(area);
		System.out.println(peri);
	}

}
/*static int l=6;
static int b=2;
public static void area()
{
	int area=l*b;                  // static method
	System.out.println("are="+area);
}
public static void per()
{
	int per=2*(l+b);
	System.out.println("peri="+per);
}
public static void main(String[]args)
{
	area();
	per();
}*/
