/*2)Write a program to calculate the cube volume,Perimeter and Area
V=a3
A= 6a2
P=6a  where a is the side of cube*/
package practiceset1;

public class VPAcube {
	public static void main(String arr[])
	{
		int a=4;
		int V=a*a*a;
		int A=6*a*a;
		int P=6*a;
		System.out.println(V);
		System.out.println(A);
		System.out.println(P);


		
	}
 
}
