/* V=a3
A= 6a2
P=6a */ 
package practiceset1;

public class VPAcubestatic {
	 static int a=2;
	 public static void vol()
	 {
		  int vol=a*a*a;
		 System.out.println("vol="+vol);
		 
	 }
	 public static void area()
	 {
		 int area=6*a*a;
		 System.out.println("area="+area);
	 }
	 public static void per()
	 {
		 int per=6*a;
		 System.out.println("per="+per);
	 }
	 public  static void main(String[]args) {
		 vol();
		 area();
		 per();
	 }
	

}
