package practiceset1;

import java.util.Scanner;

public class Remarkswitch {
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the remark:");
		char ch=sc.next().charAt(0);
		switch(ch) {
		case 'O':System.out.println("OUTSTANDING");
		break;
		case 'A':System.out.println("EXCELLENT");
		break;
		case 'B':System.out.println("VERY GOOD");
		break;
		case 'C':System.out.println("GOOD");
		break;
		case 'D':System.out.println("PASS");
		break;
		case 'E':System.out.println("ATKT");
		break;
		case 'F':System.out.println("FAIL");
		break;
		
		
		
		
		}
	}

}
