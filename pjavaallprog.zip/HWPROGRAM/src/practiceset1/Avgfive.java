/*4)WAP TO CALCULATE AVERAGE OF FIVE NUMBERS*/
package practiceset1;

public class Avgfive {
	public static void main(String arr[])
	{
       int a=10;
       int b=20;
       int c=30;
       int d=44;
       int e=50;
       int avg=(a+b+c+d+e)/5;
       System.out.println(avg);
}
}
