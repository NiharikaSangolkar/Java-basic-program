/* Write a Java program to convert temperature from Fahrenheit to Celsius degree
celsius =(( 5 *(fahrenheit - 32.0)) / 9.0);
*/
package practiceset1;

public class FtoCconv {
	public static void main(String arr[])
	{
		float fahrenheit=82.0f;
		double celsius=(( 5 *(fahrenheit - 32.0)) / 9.0);
		System.out.println(celsius);
	}

}
