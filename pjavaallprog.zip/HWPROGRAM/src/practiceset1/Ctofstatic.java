package practiceset1;
//import java.util.Scanner;

public class Ctofstatic {
	static double c=32;
	public static void fahrenite()
	{
		 double fahrenite = (c * 1.8) + 32;
		 System.out.println(fahrenite);
	}
	public static void main(String[]args)
	{
		fahrenite();
	}
	
	

}
