/*Write a Java method that will remove a given character from a string object.*/
package Stringexample;

public class removechfromstrobj {
	private static String removeChar(String str, char c) {
    if (str == null)
        return null;
    return str.replaceAll(Character.toString(c), "");
}
public static void main(String[] args) {
//removeChar("hello", 'o');
System.out.println(removeChar("hello", 'o'));
}
}

