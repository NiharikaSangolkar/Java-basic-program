package Stringexample;
/*Write a Java program to get the character at the given index within the string*/
/*
 * sample output:
Original String = Java Exercises!                                                                             
The character at position 0 is J                                                                              
The character at position 10 is i 
 * 
 * 
 * 2nd:Write a Java program to get the character (Unicode code point) at the given index within the string.

Sample Output:

Original String : w3resource.com                                                                              
Character(unicode point) = 51                                                                                 
Character(unicode point) = 101
 * 
 * */
public class s1 {
	public static void main(String[] args) {
//		String str="Java Exercises!";
//		System.out.println("The character at position 0 is "+ str.charAt(0));
//		System.out.println("The character at position 10 is "+str.charAt(10));
//	  	
	    String str="w3resource.com";
	    System.out.println(str.codePointCount(1, 9));
	    System.out.println(str.codePointBefore(1));
	    System.out.println(str.codePointBefore(9));
	    System.out.println(str.codePointAt(1));
	    System.out.println(str.codePointAt(9));
	
	}

}
