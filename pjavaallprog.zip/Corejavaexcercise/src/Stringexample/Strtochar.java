package Stringexample;

public class Strtochar {
	public static void main(String[] args) {
		String str="jouraldev";
		char[] ch=str.toCharArray();
		System.out.println(ch.length);
    	char c=str.charAt(2);
    	System.out.println(c);
//		char[]chars=new char[7];
//		str.getChars(0, 7, chars, 0);
//		System.out.println(chars);
		
	}

}
