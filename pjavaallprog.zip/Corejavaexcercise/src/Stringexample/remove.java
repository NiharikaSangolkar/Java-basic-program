package Stringexample;

public class remove {
	public static void main(String[] args) {
		String s="hello";
		System.out.println("after remove l from list: "+s.replace("l", ""));
	}

}
