package Stringexample;
/*Write a Java program to create a String object with a character array.

Sample Output:

The book contains 234 pages.*/
public class s2 {
	public static void main(String[] args) {
		char arrchar[]= new char[]{'1','2','3','4','5','6','7','8'};
		String arr_num=String.copyValueOf(arrchar,1,3);
		System.out.println("The book contains "+arr_num+" pages");
		System.out.println("The book contains "+String.copyValueOf(arrchar,2,4)+" pages");
		
	}

}
