package Stringexample;
/*
 Write a Java program to replace a specified character with another character.

Sample Output:

Original string: The quick brown fox jumps over the lazy dog.                                                 
New String: The quick brown fox jumps over the lazy fog
  
  */
public class replace {
	public static void main(String[] args) {
		String str="The quick brown fox jumps over the lazy dog.";
		System.out.println("original string: "+str);
		System.out.println("New String: "+str.replace("dog", "fog"));
		
		
	}
	



}
