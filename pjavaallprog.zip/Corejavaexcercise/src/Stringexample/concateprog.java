package Stringexample;

import java.util.Arrays;
import java.util.Scanner;

public class concateprog {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string:");
		String s =sc.next();
		System.out.println("enter the string:");
		String s1 =sc.next();
	    char str1[]=s.toCharArray();
	    char str2[]=s1.toCharArray();
	    Arrays.sort(str1);
	    Arrays.sort(str2);
	    if(Arrays.equals(str1, str1))
	    {
	    	System.out.println("its anagram");
	    }
	    else
	    {
	    	System.out.println("not anagram");
	    }
	    
	}

}
