package patternpractice;

import java.util.Scanner;

public class Scannnerpatter {
	public static void main(String[] args) {
		//int n=4;
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		int i, j;
        for (i = 1; i <= n; i++)
        {
            for (j = 1; j <= m; j++)
            {
                if (i == 1 || i == n || j == 1 || j == m)  {          
                    System.out.print("*");            
                    }
                else {
                    System.out.print(" ");            
            }
            }
            System.out.println();
        }
      
    
	}

}
