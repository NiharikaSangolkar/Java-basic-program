package patternpractice;

public class p5 {
	public static void main(String[] args) {
		for(int i=5;i>=0;--i)
		{
			System.out.println("");
			for(int j=0;j<=i; ++j)
			{
				System.out.print("*");
			}
		}
	}

}
