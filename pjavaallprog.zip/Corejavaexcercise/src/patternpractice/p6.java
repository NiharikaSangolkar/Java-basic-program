package patternpractice;

public class p6 {
	public static void main(String[] args) {
		int k=0;
		for(int i=0;i<=5;++i,k=0)
		{
			for(int j=0;j<=5-i;++j)
			{
				System.out.println("");
			}
			while(k!=2*i-1)
			{
				System.out.print("*");
				++k;
			}
			System.out.println();
		}
	}

}
