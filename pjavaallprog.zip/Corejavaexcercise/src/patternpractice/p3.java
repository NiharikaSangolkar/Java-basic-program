/*
    * 
   * * 
  * * * 
 * * * * 
* * * * * 
  
 */
package patternpractice;

//import Classpractice.static3;

public class p3 {
	public static void pyramid(int n)
	{ 
	}
	public static void main(String[] args) {
		pyramid(5);
		
	}
	}


