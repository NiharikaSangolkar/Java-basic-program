package patternpractice;
//solid pattern
/* *****
   *****
   *****
   *****
*/
import java.util.Scanner;

public class p1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter * number which you want in verticle");
		int n=sc.nextInt();
		System.out.println("enter *number which you want in horizontle");
		int m=sc.nextInt();
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=m;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
			
	}

}
