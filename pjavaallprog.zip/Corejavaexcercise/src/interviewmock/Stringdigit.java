package interviewmock;

public class Stringdigit {
	public static void main(String[] args) {
		String str="123adv 123";
		//String num=str.indent(0);
		int num=str.length();
		for(int i=0;i<=num;i++)
		{
			if(num%str.length()==0)
			{
				System.out.println("it contains only number");
			}
			else
			{
				System.out.println("not caint number");
			}
		}
		
	}

}
