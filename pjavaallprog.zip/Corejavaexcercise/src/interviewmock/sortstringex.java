package interviewmock;

import java.util.Arrays;

public class sortstringex {
	
	public static void main(String[] args) {
		
		int arr[]= {12,56,89,90,66,97};
//		
		
		System.out.println("after sorting:");
		Arrays.sort(arr);
		
		for(int i=0;i<=arr.length;i++)
		{
			System.out.println(arr[i]);
		}
	
}

}
