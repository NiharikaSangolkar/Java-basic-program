package interviewmock;

import java.util.Arrays;
import java.util.Comparator;

public class p12longestarray {
	public static void main(String[] args) {
		String str[]= {"heklll","ugduhfdjgf","helooooooooon"};
		String longest=Arrays.stream(str).max(Comparator.comparing(String::length)).get();
		System.out.println("longest sequence of arrays:"+longest);
	}

}
