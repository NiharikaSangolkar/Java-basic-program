package interviewmock;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;

public class LinkedListex {
	public static void main(String[] args) {
		LinkedList<Integer> li=new LinkedList<Integer>();
		li.add(12);
		li.add(34);
		li.add(44);
		li.add(64);
		li.add(44);
		li.add(14);
		//Arrays.sort(li);
		//li.sort((Comparator<? super Integer>) li);
		
		System.out.println(li);
		for(Integer l:li)
		{
			//if(li.next())
			System.out.println(li);
		}
		//Integer l;
		
	}

}
