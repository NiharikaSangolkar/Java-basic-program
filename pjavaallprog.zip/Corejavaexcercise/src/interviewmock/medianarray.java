package interviewmock;

import java.util.Arrays;

public class medianarray {
	public static void main(String[] args) {
		int arr[]= {12,67,89,90,95};
		int arr1[]= {12,67,89,90,95};
		Arrays.sort(arr);
		Arrays.sort(arr1);
		//int[] result1=(arr.length+arr1.length)/2;
		
		// int result=arr+arr2;
	     
	}

}
