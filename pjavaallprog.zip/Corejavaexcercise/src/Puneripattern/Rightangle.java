package Puneripattern;

import java.util.Scanner;

public class Rightangle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int num=sc.nextInt();
		int i;
		int j;
		for( i=1;i<=num;i++)
		{
			System.out.print("");
			//System.out.println("");
			for( j=1;j<=i;j++)
			{
				System.out.print(j);
			}
			System.out.println(" ");
			
		}
	}

}
