package Puneripattern;
//19 march
import java.util.Scanner;

public class Greater {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the 1st number:");
		int a = sc.nextInt();
		System.out.println("enter the 2nd number:");

		int b = sc.nextInt();
		System.out.println("enter the 3rd number:");

		int c = sc.nextInt();
		if (a > b && a > c) {
			System.out.println("the  greastest number:" + a);
		} else if (b > a && b > c) {
			System.out.println("the greatest number" + b);
		} else {
			System.out.println("the greatest number:" + c);

		}

	}

}
