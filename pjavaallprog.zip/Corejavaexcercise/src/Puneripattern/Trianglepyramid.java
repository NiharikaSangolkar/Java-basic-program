package Puneripattern;

import java.util.Scanner;

public class Trianglepyramid {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int num=sc.nextInt();
		//int num=5;
		int i;
		for( i=1;i<=num;i++)
		{
			//System.out.println("");
			for(int j=num-i;j>=0;j--)
			{
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++)
			{
				
				System.out.print(" @");
			}
			System.out.println(" ");
		}
	

}}