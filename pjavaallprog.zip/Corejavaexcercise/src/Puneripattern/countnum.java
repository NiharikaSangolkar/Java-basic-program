package Puneripattern;

import java.util.Scanner;

public class countnum {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the interger number 10 billion:");
		int num=sc.nextInt();
		int c=0;
		while(num!=0)
		{
			num=num/10;
			c++;
		}
		System.out.println("number of digit "+c);
	}

}
