package Puneripattern;

public class Pyramid {
	//private static final String StringFormatter = null;

	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("enter the number");
//		int num=sc.nextInt();
//		//int num=5;
//		int i;
//		for( i=1;i<=num;i++)
//		{
//			//System.out.println("");
//			for(int j=num-i;j>=0;j--)
//			{
//				System.out.print(" ");
//			}
//			for(int k=1;k<=i;k++)
//			{
//				
//				System.out.print(" * ");
//			}
//			System.out.println(" ");
//		}
		//System.out.println(StringFormatter.reverseString(""));
		
		 String  str="lailn";
	     String rev="";
	     int str1=str.length();
	     for(int i=str1-1;i<0;i--)
	     {
	         rev+=str.charAt(i);
	     }
	        
	        System.out.println("Try programiz.pro"+rev);
	    }
		
				
	}

