package Puneripattern;

import java.util.Scanner;

public class quardaticquestion {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of a");
		double a=sc.nextDouble();
		System.out.println("enter the value of b");
		double b=sc.nextDouble();
		System.out.println("enter the value of c");
		double c=sc.nextDouble();
		double b1=b*b-4*a*c;// b2-4ac
		
     	double b2=Math.sqrt((b1*0.5));
		double b3=(-b)+(b2);//-b+sqrt(b2)
		double b4=(-b)-(b2);
		double x=(b4)/(2*a);
		double y=(b3)/(2*a);
		if(b1>0.0 )
		{
			System.out.println("the roots are"+x+" and the roots are:"+y);
		}
		else if(b1==0.0)
		{
			System.out.println("the roots are:"+(-b/(2*a)));
		}
		else
		{
			System.out.println("invalid");
		}
		
	}

	private static double abs(double b1) {
		// TODO Auto-generated method stub
		return 0;
	}

}
