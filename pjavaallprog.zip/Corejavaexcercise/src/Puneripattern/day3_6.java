package Puneripattern;

import java.util.Scanner;

public class day3_6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the alphabet");
		String ch = sc.next();
		if(ch.equalsIgnoreCase("A")||ch.equalsIgnoreCase("E")||ch.equalsIgnoreCase("I") || ch.equalsIgnoreCase("O")
				|| ch.equalsIgnoreCase("U")) {
			System.out.println("its a vowel");

		} else if (ch.length() > 1) {
			System.out.println("error message ");
		} else {
			System.out.println("input letter is consonent");
		}

	}
}
