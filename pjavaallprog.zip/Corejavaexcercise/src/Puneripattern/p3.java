package Puneripattern;

import java.util.Scanner;

public class p3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		float num = sc.nextFloat();
		if (num == 0) {
			System.out.println("number is zero");
		} else {
			if (num > 0) {
				System.out.println(" positive number");
				if (num > 1000000) {
					System.out.println("number is larger");
				}
			} else if (num < 0) {
				System.out.println("negative number");
				if (num<1) {
					System.out.println("number is small");
				}
			}

		}

	}

}
