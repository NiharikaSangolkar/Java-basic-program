package multi;

public class Vehicle {
	public  void speedup()
	{
		System.out.println("speed of vehicles:");
	}

}
