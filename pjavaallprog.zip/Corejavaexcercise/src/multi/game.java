package multi;

public class game {
	public void  game()
	{
		System.out.println("games are:");
	}

}
