package multi;

public class c1 extends chess {
	public void cgame(int p,String n)
	{
		System.out.println("player size:"+p);
		System.out.println("game name:"+n);
	}
	public static void main(String[] args) {
		c1 d =new c1();
		d.game();
		d.chessgame(2, "chess");
		d.cgame(11, "cricket");
	}

}
