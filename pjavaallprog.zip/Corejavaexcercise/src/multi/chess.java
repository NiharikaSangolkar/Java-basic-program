package multi;

public class chess extends game{
	public void chessgame(int p,String n)
	{
		System.out.println("player size:"+p);
		System.out.println("game name:"+n);
	}

}
