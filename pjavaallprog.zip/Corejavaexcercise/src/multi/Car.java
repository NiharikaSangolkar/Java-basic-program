package multi;

public class Car extends Vehicle {
	@Override
	public void speedup()
	{
		System.out.println("speed of car:48km/hr");
	}

}
