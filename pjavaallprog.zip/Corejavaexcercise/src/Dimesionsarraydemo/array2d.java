package Dimesionsarraydemo;
import java.util.*;

import java.lang.reflect.Array;

public class array2d {
	public static void main(String[] args) {
		
		    int[][] myNumbers = { {1, 2, 3, 4}, 
		    		{5, 6, 7},
		    		{4,6,7,8},
		    		{4,5,6,8,4,7}
		    		};
		    for (int i = 0; i < myNumbers.length; ++i) {
		    	int sum=0;
		      for(int j = 0; j < myNumbers[i].length; ++j) {
		    	  sum+=myNumbers[i][j];
		        System.out.println("sum of number"+(i+1)+":"+sum);
		      }
		    }
		  }

	

}
