package Interfacedemo;

public class sq implements shp2{
	@Override
	public void getarea()
	{
		int a=4;
		System.out.println("area of square:"+a*a);
	}
	public static void main(String[] args) {
		rec r=new rec();
		r.getarea();
		sq s= new sq();
		s.getarea();
	}

}
