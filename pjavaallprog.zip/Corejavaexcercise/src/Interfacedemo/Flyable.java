/*Write a Java program to create an interface Flyable with a method called fly_obj(). 
 * Create three classes Spacecraft, Airplane, and Helicopter that implement the Flyable interface. 
 * Implement the fly_obj() method for each of the three classes.
 *  
 * ambiguity(diamond problem)the compiler cannot be identify which is superclass or childclass*/
package Interfacedemo;

public interface Flyable {
	void fly_obj(String a);

}
