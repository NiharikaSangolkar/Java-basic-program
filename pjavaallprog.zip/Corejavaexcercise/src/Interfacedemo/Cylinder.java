package Interfacedemo;

public class Cylinder implements Operation {
	double pi=3.14;
	@Override
	public void area(int r,int h)
	{ 
		
		System.out.println("area of cylinder:"+((2*pi*r*h)+(2*pi*r*h)));
	}
	@Override
	public void vol(int r,int h)
	{
		System.out.println("volume of cylinder:"+(2*pi*r*h));
		
	}
	public static void main(String[] args) {
		Cylinder c=new Cylinder();
		c.area(3, 4);
		c.vol(3, 4);
	}

	

}
