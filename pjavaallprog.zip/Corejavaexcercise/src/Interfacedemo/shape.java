package Interfacedemo;

public interface shape {
	 void getarea();

}

