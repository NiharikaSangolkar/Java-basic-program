package Interfacedemo;

public interface shp2 {
	public abstract void getarea();

}
