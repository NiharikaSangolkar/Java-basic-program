package Interfacedemo;

public class squaresh2 implements Shape2{
  @Override
  public void getarea()
  {
	  int a=6;
	  System.out.println("area of square:"+a*a);
	  
  }
  public static void main(String[] args) {
	squaresh2 s=new squaresh2();
	s.getarea();
	rectanglesh2 r=new rectanglesh2();
	r.getarea();
	
}

}
