package Interfacedemo;

public class Helicopter implements Flyable{
	@Override
	public void fly_obj(String b)
	{
		System.out.println("flying object:"+b);
	}
	public static void main(String[] args) {
		Spacecraft s=new Spacecraft();
		s.fly_obj("Spacecraft");
		Airoplane a=new Airoplane();
		a.fly_obj("Airoplane");
		Helicopter h=new Helicopter();
		h.fly_obj("Helicopter");
	}
}


