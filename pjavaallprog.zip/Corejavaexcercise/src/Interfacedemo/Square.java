package Interfacedemo;

public class Square implements shape{
	@Override
	public void getarea()
	{
		int a=5;
		System.out.println("area of square:"+(a*a));
	}
	public static void main(String[] args) {
		Square s=new Square();
		s.getarea();
		Rectangle r=new Rectangle();
		r.getarea();
	}



}
