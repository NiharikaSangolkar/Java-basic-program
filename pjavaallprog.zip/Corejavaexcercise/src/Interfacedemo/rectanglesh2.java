package Interfacedemo;

public class rectanglesh2 implements Shape2{
	@Override
	public void getarea()
	{
		int l,b;
		l=4;b=7;
		System.out.println("area of rectangle:"+l*b);
		
		
	}
	
	

}
