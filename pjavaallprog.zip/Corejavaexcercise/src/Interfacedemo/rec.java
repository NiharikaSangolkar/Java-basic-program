package Interfacedemo;

public class rec implements shp2{
	@Override
	public void getarea()
	
	{
		int l=7,b=6;
		System.out.println("area of rectangle"+l*b);
	}

}
