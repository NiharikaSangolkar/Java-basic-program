package Interfacedemo;

public class Rectangle implements shape{
	@Override
	public void getarea()
	{
		int l=2;
		int b=3;
		System.out.println("area of rectangle:"+(l*b));
		
	}





}
