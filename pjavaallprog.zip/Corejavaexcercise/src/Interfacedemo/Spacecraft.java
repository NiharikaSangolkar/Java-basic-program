package Interfacedemo;

public class Spacecraft implements Flyable {
	@Override
	public void fly_obj(String a)
	{
		System.out.println("Flyable object:"+a);
	}




}
