package Interfacedemo;

public interface Operation {
	public void area(int r,int h);
	public void vol(int r,int h);

}
