package Interfacedemo;

public interface Shape2 {
	public abstract void getarea();

}
