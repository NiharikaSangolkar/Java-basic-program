package Interfacedemo;

public class Airoplane implements Flyable{
	@Override
	public void fly_obj(String b)
	{
		System.out.println("flying object:"+b);
	}




}
