package Interfacedemo;
import java.util.*;
//import java.awt.*;


public class Rectangleresize implements Resizable {
	private int wd;
	private int ht;
	public Rectangleresize(int w,int h)
	{
		//System.out.println();
		this.wd=w;
		this.ht=h;
	}
	@Override
	public void resizeWidth(int w)
	{
		this.wd=w;
		
	}
	@Override
	public void resizeheight(int h)
	{
		this.ht=h;
		
	}
	public void resize()
	{
		System.out.println("width :"+wd+  " height:"+ht);
	}
	public static void main(String[] args) {
		Rectangleresize r=new Rectangleresize(100,150);
		r.resize();
		r.resizeWidth(140);
		r.resizeheight(145);
		r.resize();
	}




}
