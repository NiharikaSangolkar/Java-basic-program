/* Write a Java program to convert minutes into years and days.

Test Data
Input the number of minutes: 3456789
Expected Output :
3456789 minutes is approximately 6 years and 210 days*/
package Datatypesdemo;

import java.util.Scanner;

public class p4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter minutes:");
		double m=sc.nextDouble();
		//double y=60*24*365;
		long yr=(long)(m/(60*24*365));
		System.out.println("");
		int d=(int)((m/60/24)%365);
		System.out.println(m+" minutes is approximately "+yr+" years and "+d+" days.");
		}
		
	}





