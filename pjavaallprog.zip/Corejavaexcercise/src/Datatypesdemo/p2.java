/*Write a Java program that reads a number in inches and converts it to meters.
Note: One inch is 0.0254 meter.
Test Data
Input a value for inch: 1000
Expected Output :
1000.0 inch is 25.4 meters*/
package Datatypesdemo;

public class p2 {
	public static void main(String[] args) {
		double och=0.0254;
		double inch=1000;
		System.out.println(inch+ " inch is "+(och*inch)+ " meter.");
	}


}