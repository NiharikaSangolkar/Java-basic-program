/* Write a Java program to compute the body mass index (BMI).

Test Data
Input weight in pounds: 452
Input height in inches: 72
Expected Output:
Body Mass Index is 61.30159143458721
*/
package Datatypesdemo;

import java.util.Scanner;

public class p5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter weight in pounds:");
		int w=sc.nextInt();
		double p=0.45359237*w;
		System.out.println("enter height in inches:");
		int h=sc.nextInt();
		double in=0.0245*h;
		System.out.println("body mass index is: "+(p/(in*in)));
	}

	

}
