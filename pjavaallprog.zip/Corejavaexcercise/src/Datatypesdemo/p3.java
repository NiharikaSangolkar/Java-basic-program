/*Write a Java program that reads an integer between 0 and 1000 and adds all the digits in the integer.

Test Data
Input an integer between 0 and 1000: 565
Expected Output :
The sum of all digits in 565 is 16*/

package Datatypesdemo;

import java.util.Scanner;

public class p3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter input betweem 0 to 1000:");
		int n=sc.nextInt();
		int f=n%10;
		int r=n/10;
		int s=r%10;
		r=r/10;
		int t=r%10;
		r=r/10;
		int fr=r%10;
		int sum=f+s+t+fr;
		System.out.println("the sum of all digits in "+n+" is "+sum);
		
	}

	
}
