/*Write a Java program to create a class called Shape with a method called getArea(). 
 * Create a subclass called Rectangle that overrides the getArea() 
 * method to calculate the area of a rectangle.*/
package SingleInheritancedemo;

public class Shape {
	 public void getarea()
	{
		 System.out.println("area of rectangle");
		
	}

}
