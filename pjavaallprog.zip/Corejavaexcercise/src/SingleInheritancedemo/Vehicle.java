/*Write a Java program to create a class called Vehicle with a method called drive(). 
 Create a subclass called Car that overrides the drive() method to print "Repairing a car".
*/
package SingleInheritancedemo;

public class Vehicle {
	public void drive()
	{
		System.out.println("vehicles are reparing");
	}

}
