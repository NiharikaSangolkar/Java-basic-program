package SingleInheritancedemo;

import java.util.Scanner;

public class rectangle extends Shape  {
	public void getarea() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length:");
		int l=sc.nextInt();
		System.out.println("enter breadth:");
		int b=sc.nextInt();
		System.out.println(l*b);


	}
	public static void main(String[] args) {
		Shape s=new Shape();
		//s.getarea();
		rectangle r=new rectangle();
		
		r.getarea();
		s.getarea();
	}

}
