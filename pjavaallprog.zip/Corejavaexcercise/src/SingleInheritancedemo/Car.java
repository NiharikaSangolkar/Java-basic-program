package SingleInheritancedemo;

public class Car extends Vehicle{
	public void drive()
	{
		System.out.println("repairing a car");
	}
	public static void main(String[] args) {
		Vehicle v=new Vehicle();
		v.drive();
		Car c=new Car();
		c.drive();

	}

}
