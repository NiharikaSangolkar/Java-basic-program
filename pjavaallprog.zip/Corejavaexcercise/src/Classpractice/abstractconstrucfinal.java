/*develop a program to demonstrate the concept of abstract class
  with constructor and “final“ method. */
package Classpractice;

public  abstract class abstractconstrucfinal {
	public void abstractconstrucfinal () {
		System.out.println("I am constructor with abstract class");
	}
	public static void main(String[] args) {

	}

}
