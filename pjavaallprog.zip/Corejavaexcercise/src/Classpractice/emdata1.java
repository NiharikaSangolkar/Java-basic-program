package Classpractice;

public class emdata1 extends emdata{
	
	public void details()
	{
		int id=34;
		System.out.println("employee id:"+id);
	}

   public static void main(String[] args) {
	   emdata1 d=new emdata1();
	   d.detail_e();
	   d.detail();
	   d.details();
	
}

}
