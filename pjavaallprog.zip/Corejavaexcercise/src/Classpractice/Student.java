//4:this
package Classpractice;

public class Student {
	public void data()
	{ this.student_detail("riya", 346);
		System.out.println("student details");
		
	}
	public void student_detail(String name,int id)
	{
		System.out.println("student name and id :"+(name)+ " "+ (id));
		
	}
	public static void main(String[] args) {
		Student s=new Student();
		s.data();
	}

}
