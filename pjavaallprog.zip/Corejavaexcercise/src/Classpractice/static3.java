/*Develop a program in Java to demonstrate the use of static variable, 
 * static method and static block.*/
package Classpractice;

public class static3 {
	//static variable
	static int x=6;
	static int y;
	//static method
public static void fun(int z)
	{
	  System.out.println("x:"+x);
	  System.out.println("y:"+y);
	  System.out.println("z:"+z);
		
	}
//static block
  static
{
	 y= x+4;
	  System.out.println("satic block initiallze");
	
}
  public static void main(String[] args) {
	fun(5);
}
	

}
