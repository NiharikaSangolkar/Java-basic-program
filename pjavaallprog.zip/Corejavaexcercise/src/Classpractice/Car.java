package Classpractice;

public class Car extends Hvehicle{
	@Override
	public void drive()
	{
		System.out.println("car drive");
	}

}
