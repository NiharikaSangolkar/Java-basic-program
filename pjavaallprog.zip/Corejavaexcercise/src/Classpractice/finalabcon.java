package Classpractice;

public class finalabcon extends abstractconstrucfinal {
	@Override
	public  void abstractconstrucfinal() {
		
		// TODO Auto-generated constructor stub
	}

}
