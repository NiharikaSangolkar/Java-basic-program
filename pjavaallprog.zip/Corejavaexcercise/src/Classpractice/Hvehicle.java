package Classpractice;

public class Hvehicle {
	public void drive()
	{
		System.out.println("vehicles are driving");
	}

}
