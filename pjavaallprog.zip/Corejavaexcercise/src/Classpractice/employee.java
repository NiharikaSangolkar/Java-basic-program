package Classpractice;

public class employee {
	public void detail_e() {
		System.out.println("employee details");
	}



}
