package Classpractice;

public class Truck extends Hvehicle {
	@Override
	public void drive() {
		System.out.println("truck drive");


	}
	public static void main(String[] args) {
		Truck h=new Truck();
		h.drive();
		Hvehicle g=new Hvehicle();
		g.drive();
		Car c=new Car();
		c.drive();
	}

}
