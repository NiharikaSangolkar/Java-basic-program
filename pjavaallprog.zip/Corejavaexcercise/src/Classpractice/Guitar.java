package Classpractice;

public class Guitar extends ES {
	public void display()
	{
		super.data();
		System.out.println("guitar");
	}
	public static void main(String[] args) {
		Guitar g=new Guitar();
		g.display();
	}

}
