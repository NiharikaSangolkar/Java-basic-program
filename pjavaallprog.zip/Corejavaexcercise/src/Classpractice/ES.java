package Classpractice;

public class ES {

		public void data()
		{ 
			
			System.out.println("instruments");
			
		}
		

	


}
