package Classpractice;

public class Rectangle {
	 private int l;
	 private int b;
	public void getDimension(int lt,int bt)
	{
		l=lt;
		b=bt;
		System.out.println("length of rectangle:"+lt);
	    System.out.println("breadth of rectangle:"+bt);
	}
	public void findArea()
	{
		System.out.println("area of rectangle:"+(l*b));
		
	}
	public static void main(String[] args) {
		Rectangle r=new Rectangle();
		r.getDimension(4, 5);
		System.out.println();
		r.findArea();
	}

}
