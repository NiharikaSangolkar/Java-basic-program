package Classpractice;

public class emdata extends employee {
	
	public void detail() {
		String name="riya";
		System.out.println("employee name:"+name);


	}

}
