package Classpractice;

public class Square {
	public void areasquare()
	{
		int a=5;
		System.out.println("area of square:"+(a*a));
	}
	
	public void areatriangle()
	{
		int l=3;
		int h=4;
		System.out.println("area of traingle:"+(0.5*l*h));
	}
	public void arearectangle()
	{
		int l=5;
		int b=6;
		System.out.println("area of rectangle:"+(l*b));
	}
	public static void main(String[] args) {
		Square s=new Square();
		s.areasquare();
		s.areatriangle();
		s.arearectangle();
	}

}
