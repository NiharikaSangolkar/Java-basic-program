/* Write a Java program to create a class called Employee with methods called work() 
 *and getSalary().Create a subclass called HRManager that overrides the work() method and 
 *adds a new method called addEmployee().*/
package Inheritancedemo;

public class Employee {
	public void work(int h)
	{
		System.out.println("Employee work hours: "+h);
	}
	public void getsalary(double sal)
	{
		System.out.println("Employee salary: "+sal);
		
	}

}
