package Inheritancedemo;

public class Car extends Vehicle{
	@Override
	public void drive() {
		System.out.println("Repairing a car");
	}
	public static void main(String[] args) {
		Car c=new Car();
		c.drive();
		Vehicle v=new Vehicle();
		v.drive();
	}

}
