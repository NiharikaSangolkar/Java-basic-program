package Inheritancedemo;

public class HrManager extends Employee{
	@Override
	public void work(int h) {
		System.out.println("HR Manager work hours :"+h);
		
	}
	@Override
	public void getsalary(double sal) {
		System.out.println("HR Manager salary :"+sal);


	}
	public void addemployee(String n)
	{
		System.out.println("New employee is join as a HR Manager "
				+ "and his name is: "+n);
		
	}
	public static void main(String[] args) {
		Employee e=new Employee();
		e.work(7);
		e.getsalary(58000);
		HrManager hm=new HrManager();
		hm.addemployee("Ram Kapoor");
		hm.work(5);
		hm.getsalary(56000);
		
	}

}
