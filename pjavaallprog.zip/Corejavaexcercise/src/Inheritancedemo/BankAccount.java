package Inheritancedemo;

public class BankAccount {
	private int acno;
	private int balance;
	public int getAcno() {
		return acno;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public static void main(String[] args) {
		BankAccount b=new BankAccount();
		b.setAcno(379794899);
		b.setBalance(87878);
		b.getAcno();
		b.getBalance();
		System.out.println("account nu:"+b.getAcno());
		System.out.println("balance:"+b.getBalance());
	}

}
