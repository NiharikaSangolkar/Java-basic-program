package Inheritancedemo;

public class Cat extends Animal {
	public void makeSound()
	{
		System.out.println("cat is making sound meow meow");
		
	}
	public static void main(String[] args) {
		Cat c=new Cat();
		c.makeSound();
		
	}
	

}
