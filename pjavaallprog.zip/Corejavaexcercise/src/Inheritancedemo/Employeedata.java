package Inheritancedemo;

public class Employeedata {
	private int id;
	private String empname;
	private double salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public static void main(String[] args) {
		Employeedata e=new Employeedata();
		e.setEmpname("riya");
		e.setId(12);
		e.setSalary(89759);
		System.out.println("id:"+e.getId());
		System.out.println("name:"+e.getEmpname());
		System.out.println("salary:"+e.getSalary());
	}
	

}
