package Inheritancedemo;

public class Employeeperson extends Person {

@Override
	public void getLastName(String l) {
	     String s="HR ";
	     System.out.println("job title:"+s);
		System.out.println("last name:"+l);
	}
   public void getEmployeeid(int i)
   {
	   System.out.println("employee id:"+i);
	   
   }
   public static void main(String[] args) {
	   Person p=new Person();
	   p.getFirstName("Ram");
	   p.getLastName("kappor");
	   System.out.println();
	   Employeeperson e=new Employeeperson();
	   e.getEmployeeid(34);
	   e.getLastName("Mishra");
	
}
   


}
