package PracticeBasic;

public class T1 {

}
