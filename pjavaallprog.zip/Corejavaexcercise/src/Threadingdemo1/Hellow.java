/*Write a Java program to create a basic Java thread that prints "Hello, World!" when executed.*/
package Threadingdemo1;

public class Hellow extends Thread{
	@Override
	public void run() {
		System.out.println("Hello world!");
	}
	public static void main(String[] args) {
		Hellow h=new Hellow();
		h.start();
	}

}
