package Threadingdemo1;


class odd extends Thread{
	@Override
		public void run() {
			for(int i=1;i<=200;i+=2)
			{
				System.out.println("odd number: "+i);
				try {
					Thread.sleep(400);
					
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					// TODO: handle exception
				}
			}
		}
}
	class even extends Thread{
		@Override
			public void run() {
				for(int i=2;i<=200;i+=2)
				{
					System.out.println("even number: "+i);
					try {
						Thread.sleep(400);
						
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
						// TODO: handle exception
					}
				}
			}
	}
	public class oddeven {
		public static void main(String[] args) {
			odd o=new odd();
			o.start();
			even e=new even();
			e.start();
			
			
		}
	}





