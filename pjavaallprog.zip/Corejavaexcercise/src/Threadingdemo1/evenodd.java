package Threadingdemo1;

import java.util.Scanner;

public class evenodd extends Thread {
	@Override
	public void run() {
		//int num=21;
		Scanner s=new Scanner(System.in);
		System.out.println("enter number:");
		int num=s.nextInt();
		if(num%2==0)
		{
			System.out.println("even number");
		}
		else
		{
			System.out.println("odd number");
		}


	}
	public static void main(String[] args) {
		evenodd e=new evenodd();
		e.start();
	}

}
