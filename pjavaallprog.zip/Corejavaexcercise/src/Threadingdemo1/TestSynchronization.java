package Threadingdemo1;



class Table 
{
	public synchronized void printtable(int n)
	{
		System.out.println("hello threading");
		System.out.println("threading ......?");
		synchronized (this) {
			
		}
		for(int i=1;i<=5;i++)
		{
			
			System.out.println(n*i);
			try {
				Thread.sleep(500);

			} catch (Exception e) {
				System.out.println(e);
				// TODO: handle exception
			}
		}
	}
}
	class Mythread1 extends Thread{
		Table t;
		Mythread1(Table t)
		{
			this.t=t;

		}

		public void run() {
			t.printtable(5);

		}

	}
	class Mythread2 extends Thread{
		Table t;
		Mythread2(Table t)
		{
			this.t=t;

		}

		public void run() {
			t.printtable(100);

		}
	}

public class TestSynchronization {
	public static void main(String[] args) {
	Table obj=new Table();
	Mythread1 t1 =new Mythread1(obj);
    Mythread2 t2=new Mythread2(obj);
	t1.start();
	t2.start();

}
}
