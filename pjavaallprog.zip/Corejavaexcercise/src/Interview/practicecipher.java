package Interview;

//import java.nio.file.ReadOnlyFileSystemException;
import java.util.Scanner;

public class practicecipher {
	public static StringBuffer encrypt()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the text:");
		String text=sc.nextLine();
		System.out.println("enter the shifts:");
		int s=sc.nextInt();
		StringBuffer result=new StringBuffer();
		for(int i=0;i<text.length();i++)
		{
		if(Character.isUpperCase(text.charAt(i)))
		{
			char ch=(char)(((int)text.charAt(i)+s-65)%26+65);
			result.append(ch);
		}
		else
		{
			char ch=(char)(((int)text.charAt(i)+s-97)%26+97);
			result.append(ch);
		}
		}
		
		
		return result;
	}
	public static void main(String[] args) {
		encrypt();
	}

}
