//Niharika Sangolkar
package Interview;

import java.util.Scanner;

public class LongestPalindromeSubstring {
    public static String longestPalindromeSubstring(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }

        String longest = s.substring(0, 1);

        for (int i = 0; i < s.length(); i++) {
            String palindrome1 = expandAroundCenter(s, i, i);
            String palindrome2 = expandAroundCenter(s, i, i + 1);
            //String p=expandAroundCenter(longest, i, i)
            String maxPalindrome = palindrome1.length() > palindrome2.length() ? palindrome1 : palindrome2;

            if (maxPalindrome.length() > longest.length()) {
                longest = maxPalindrome;
            }
        }

        return longest;
    }

    private static String expandAroundCenter(String s, int left, int right) {
        while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
            left--;
            right++;
        }
        return s.substring(left + 1, right);
    }

    public static void main(String[] args) {
        System.out.println(longestPalindromeSubstring("banana")); // Output: "anana"
        System.out.println(longestPalindromeSubstring("xyz")); // Output: "x" or "y" or "z"
    }
}