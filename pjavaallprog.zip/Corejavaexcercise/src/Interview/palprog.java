package Interview;

import java.util.Scanner;

public class palprog {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter thenumber:");
		int n=sc.nextInt();
		int m=n,rev=0;
		while(n>0)
		{
			rev=(rev*10)+(n%10);
			n=n/10;
		}
		if(rev==m)
		{
			System.out.println("its palindrome");
		}
		else
		{
			System.out.println("its not  palindrome");
		}
	}

}
