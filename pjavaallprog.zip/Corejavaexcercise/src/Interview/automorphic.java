package Interview;

import java.util.Scanner;

public class automorphic {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int sqrt=n*n;
	    String lsnum=Integer.toString(n);
	    String square=Integer.toString(sqrt);
	    if(square.endsWith(lsnum))
	    {
	    	System.out.println("its automphic:"+n);
	    }
	    else
	    {
	    	System.out.println("its not  automphic:"+n);
	    }
	    
	
	}

}
