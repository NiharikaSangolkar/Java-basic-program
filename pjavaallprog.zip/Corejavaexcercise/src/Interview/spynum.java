package Interview;

import java.util.Scanner;

public class spynum {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int sum=0,prod=1;
		while(n>0)
		{
			sum=sum+n%10;
			prod=prod*(n%10);
			n=n/10;
		}
		if(sum==prod)
		{
			System.out.println("its spy");
		}
		else
		{
			System.out.println("its not  spy");
			
		}
	}

}
