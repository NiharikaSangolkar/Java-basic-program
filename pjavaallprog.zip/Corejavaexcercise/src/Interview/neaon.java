package Interview;

import java.util.Scanner;

public class neaon {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int n=sc.nextInt();
		int m=n*n,sum=0;
		while(m>0)
		{
			sum=sum+(m%10);
			m=m/10;
			
		}
		if(n==sum)
		{
			System.out.println("it is neaon:"+n);
		}
		else
		{
			System.out.println("it is not neaon:"+n);
		}
		
	}

}
