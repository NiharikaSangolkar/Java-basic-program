package Interview;

import java.util.Scanner;

public class prog1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number:");
		int n=sc.nextInt();
		System.out.println("enter digit number:");
		int d=sc.nextInt();
		int temp=n,sum=0,rem;
		while(n>0)
		{
			rem=n%10;
			sum=(int) (sum+Math.pow(rem, d));
			n=n/10;
		}
		if(temp==sum)
		{
			System.out.println("its armstrong:"+temp);
		}
		else
		{
			System.out.println("its not  armstrong:"+temp);
		}
	}

}
