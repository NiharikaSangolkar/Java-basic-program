package Interview;

import java.util.Arrays;
import java.util.Scanner;

public class largerstarray {
	public static void main(String[] args) {
		//Scanner sc=new Scanner(System.in)
		int arr[]= {121,231,567,89};
		//System.out.println(Arrays.sort(arr[]));
		Arrays.sort(arr);
		System.out.println("min arrays:"+arr[0]);
		System.out.println("max arrays:"+arr[arr.length-1]);
				
	}

}
