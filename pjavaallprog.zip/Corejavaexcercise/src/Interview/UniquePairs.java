//name:Niharika Sangolkar
package Interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class UniquePairs {
    public static List<List<Integer>> uniquePairs(int[] nums, int target) {
        Set<List<Integer>> result = new HashSet<>();
        Arrays.sort(nums);
        
        int left = 0, right = nums.length - 1;
        
        while (left < right) {
            int sum = nums[left] + nums[right];
            if (sum == target) {
                List<Integer> pair = new ArrayList<>();
                pair.add(nums[left]);
                pair.add(nums[right]);
                result.add(pair);
                left++;
                right--;
            } else if (sum < target) {
                left++;
            } else {
                right--;
            }
        }
        
        return new ArrayList<>(result);
    }
    
    public static void main(String[] args) {
        int[] arr = {2, 4, 3, 2, 1, 6, 5, 8, 9, 7};
        int target = 6;
        List<List<Integer>> pairs = uniquePairs(arr, target);
        for (List<Integer> pair : pairs) {
            System.out.println(pair);
        }
    }
}
