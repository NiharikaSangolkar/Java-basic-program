package Interview;

import java.util.Scanner;

public class revstring {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		String rev="";
		//int str1=str.length();
		for(int i=str.length()-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
		}
		System.out.println("rev:"+rev);
		
	}

}
