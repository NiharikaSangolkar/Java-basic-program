package Interview;

import java.util.Scanner;

public class posneg {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int num=sc.nextInt();
	if(num>0)
	{
		System.out.println("its positve");
	}
	else
	{
		System.out.println("its negative");
	}
	
	}

}
