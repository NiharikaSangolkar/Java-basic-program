package Interview;

import java.util.Scanner;

public class primeprogh { 
	public static boolean isprime(int num)
	{
		if(num<=1)
		{
			return false;
		}
		for(int i=2;i<=Math.sqrt(num);i++)
		{
			if(num%i==0)
			{
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(isprime(n))
		{
			System.out.println("the number is prime"+n);
		}
		else
		{
			System.out.println("the  number is not S prime"+n);
		}
		}
		
	}

