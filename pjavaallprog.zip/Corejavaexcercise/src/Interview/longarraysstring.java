package Interview;

import java.util.Arrays;
import java.util.Comparator;

public class longarraysstring {
	public static void main(String[] args) {
		String name[]= {"ujdghdudgfiu","fiudyuhfhu","utdufu"};
		String longest=Arrays.stream(name).max(Comparator.comparingInt(String::length)).get();
		System.out.println("longest string:"+longest);
	}

}
