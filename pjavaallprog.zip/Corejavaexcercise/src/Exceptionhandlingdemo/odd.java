package Exceptionhandlingdemo;
import java.util.*;
//import Exceptiondemo.EvenException;

public class odd extends Exception {

	@Override
	public String toString()
	{
		return "odd number occured exception found";
		
	}
	public static void num(int n) throws odd
	{
		if(n%2!=0)
		{
			throw new odd();
			
		}
		else
		{
			System.out.println("even number:"+n);
		}
	}
	public static void main(String[] args) {
		try {
			num(5);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}



}
