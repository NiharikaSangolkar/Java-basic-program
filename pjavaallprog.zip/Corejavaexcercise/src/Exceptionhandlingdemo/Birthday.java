package Exceptionhandlingdemo;

public class Birthday extends Exception {
	@Override
	public String toString()
	{
		return" birthday date is not matching.error occcured";
	}
	public static void birth(int d,String m,int y)throws Birthday
	{
		
		int de=10;
		String mo="November";
		int ye=2001;
		if(de==d &&mo==m && ye==y)
		{
			System.out.println("birthday date is matching");
			
		}
		else
		{
			throw new Birthday();
		}
		
	}
	public static void main(String[] args) {
		try {
			birth(10,"November",2002);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	




}

