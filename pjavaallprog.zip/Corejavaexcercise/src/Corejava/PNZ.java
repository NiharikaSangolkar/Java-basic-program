package Corejava;

import java.util.Scanner;

//+tive,-tive,0
public class PNZ {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		int s = sc.nextInt();
		if (s > 0) {
			System.out.println("value is positive");
		} else if (s < 0) {
			System.out.println("its negative");
		} else {
			System.out.println("its zero");
		}
	}

}
