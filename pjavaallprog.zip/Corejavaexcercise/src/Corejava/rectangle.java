/*Given the length and breadth of a rectangle, write a java program to find 
 whether the area of the rectangle is greater than its perimeter.
*/
package Corejava;

import java.util.Scanner;

public class rectangle {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length");
		int l=sc.nextInt();
		System.out.println("enter rectangle");
		int b=sc.nextInt();
		int area=l*b;
		int perimeter=2*(l+b);
		if(area>perimeter)
		{
			System.out.println("area of rectangle is greater:"+area);
		}
		else
		{
			System.out.println("perimeter of rectangle is greater:"+perimeter);
		}
		
	}

}
