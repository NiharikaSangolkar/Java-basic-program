package Corejava;

import java.util.Scanner;

public class fpa {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number:");
		int n=sc.nextInt();
		int temp,sum=0,r;
//		int n1=0,n2=1,n3,c=0;
//		while(c<n)
//		{
//			System.out.println(n1+"");
//			n3=n1+n2;
//			n1=n2;
//			n2=n3;
//			c+=1;
//		}
		temp=n;
		while(n>0)
		{
			r=n%10;
			sum=(sum*10)+r;
			n=n/10;
		}
		if(temp==sum)
		{
			System.out.println("its palindrome");
		}
		else
		{
			System.out.println("not palindrome");
		}
	}

}
