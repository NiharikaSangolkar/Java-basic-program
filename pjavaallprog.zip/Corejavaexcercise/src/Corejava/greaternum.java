package Corejava;

public class greaternum {
	public static void main(String[] args) {
		int x = 7, y = 18, z = 9;
		if (x > y && x > z) {
			System.out.println("x is greater" + x);
		} else if (y > x && y > z) {
			System.out.println("y is greater"+y);
		} else {
			System.out.println("z is greater" + z);
		}
	}

}
