/* Write a program to calculate the salary as per the following table

Gender	Year of Service	Qualifications	Salary
Male	>= 10	        Post - Graduate	15000
        >= 10	            Graduate	10000
        < 10	       Post - Graduate	10000
        < 10	          Graduate   	7000
        
        
Female	>= 10	      Post - Graduate	12000
        >= 10	            Graduate	9000
        < 10	      Post - Graduate	10000
        < 10	            Graduate	6000
*/

package Corejava;
import java.util.*;
import java.util.Scanner;

//import Classpractice.static3;

public class salary {
	public static void female()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter Year of Service:");
		int y=s.nextInt();
		System.out.println("enter Qualifications:");
		String q=s.next();
		if(y>=10 && q.equalsIgnoreCase("pg"))
		{
			System.out.println("salary is 12000");
		}
		else if(y>=10 && q.equalsIgnoreCase("g"))
		{
			System.out.println("salary is 9000");
		}
		else if(y<10 && q.equalsIgnoreCase("pg"))
		{
			System.out.println("salary is 10000");
			
		}
		else if(y<10 && q.equalsIgnoreCase("g"))
		{
			System.out.println("salary is 6000");
			
		}
		
	}
	public static void male()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter Year of Service:");
		int y=s.nextInt();
		System.out.println("enter Qualifications:");
		String q=s.next();
		if(y>=10 && q.equalsIgnoreCase("pg"))
		{
			System.out.println("salary is 15000");
		}
		else if(y>=10 && q.equalsIgnoreCase("g"))
		{
			System.out.println("salary is 10000");
		}
		else if(y<10 && q.equalsIgnoreCase("pg"))
		{
			System.out.println("salary is 10000");
			
		}
		else if(y<10 && q.equalsIgnoreCase("g"))
		{
			System.out.println("salary is 7000");
			
		}
	}
	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		System.out.println("enter gender");
		String g=sc.next();
		if(g.equalsIgnoreCase("male"))
		{
			male();
			
		}
		else if(g.equalsIgnoreCase("female"))
		{
			female();
		}
		else
		{
			System.out.println("plese enter your  correct gender male/female");
		}
		
	}

}
