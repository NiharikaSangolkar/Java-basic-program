//A student will not be allowed to sit in exam if his/her attendence is less than 75%.
//Take following input from user
//Number of classes held
//Number of classes attended.
//And print
//percentage of class attended
//Is student is allowed to sit in exam or not.
//
//also check  if he/she has medical cause. Ask user if he/she has medical cause or not ( 'True' or 'False' ) and print accordingly.


package Corejava;

import java.util.Scanner;

public class Medical {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter number of class held:");
		double h=s.nextDouble();
		System.out.println("enter number of class attended");
		double a=s.nextDouble();
		double per=(a/h)*100;
		if(per<75)
			{
			System.out.println("your attendance is very low and percentage: "+per);
			System.out.println("do you have any medical reasons ,say yes or no");
			String re=s.next();
			if(re.equalsIgnoreCase("yes"))
			{
				System.out.println("allow to exam");
			}
			else
			{
				System.out.println("not allow to exam");
			}
		}
		else
		{
			System.out.println("you allow to exam and percentage:"+per);
		}
		
	}

}
