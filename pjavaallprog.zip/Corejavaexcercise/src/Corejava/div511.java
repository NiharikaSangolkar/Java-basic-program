package Corejava;

import java.util.Scanner;

public class div511 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		if(n%5==0 && n%11==0)
		{
			System.out.println("number is divisible 5 and 11");
		}
		else
		{
			System.out.println("number is not divisble by 5  and 11");
		}
	}

}
