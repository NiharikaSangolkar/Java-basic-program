package Hacckerrankproblem;

public class Datastrig {

}
