package Multilevelinheritenc;

public class Savingaccount extends Account {
	public void savingaccount(int mb,int sb)
	{
		System.out.println("min bal :"+mb);
		System.out.println("saving balance:"+sb);
		
	}
	

}
