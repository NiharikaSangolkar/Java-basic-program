package Multilevelinheritenc;

public class Accountdetail extends Savingaccount{
	public void accountdetail(int d,int w)
	{
		System.out.println("deposite:"+d);
		System.out.println("withdraw:"+w);
		
	}
	public static void main(String[] args) {
		Accountdetail a=new Accountdetail();
		a.account("riya kapoor", 34234344);
		a.savingaccount(500, 5450);
		a.accountdetail(400, 100);		
	}

}
