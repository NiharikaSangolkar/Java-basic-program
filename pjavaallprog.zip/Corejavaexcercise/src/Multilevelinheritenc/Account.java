/*
1.Write a program to implement the following Multi Level Inheritance:
Class: Account
data members  : Cust_name , acc_no
                         
Class: Saving_Acc
data members  : Min_bal, saving_bal

Class:Acct_Details
data members  : Deposits, withdrawals*/
package Multilevelinheritenc;

public class Account {
	public void account(String cust,int acc)
	{
		System.out.println("coustomer name:"+cust);
		System.out.println("account number:"+acc);
		
	}

}
