package Interviewprogram;

import java.util.Scanner;

// o112358
public class fibonnacie {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int num=sc.nextInt();
		//System.out.println("fibbonacies series are:");
		int n1=0,n2=1,count=0,n3;
		while(count<num)
		{
			System.out.println(n1+"");//0
			n3=n1+n2; // n3=0+1;=1
			n1=n2; //n1=1;
			n2=n3;
			count+=1;
			
			
			
		}
		
	}

}
