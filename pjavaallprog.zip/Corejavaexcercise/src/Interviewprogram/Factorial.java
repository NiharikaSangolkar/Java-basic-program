package Interviewprogram;

import java.util.Scanner;

public class Factorial {
	public static boolean isprime(int num)
	{
		if(num==1)
		{
			return false;
		}
		if(num==2)
		{
			return true;
		}
		for(int i=2;i<=num/2;i++)
		{
			if(num%i==0) {
			return false;
		}}
		return true;
		
	}
	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("enter the number:");
//		int fact=1;
//		int n=sc.nextInt();
//		for(int i=1;i<=n;i++)
//		{
//			fact*=i;
//		}
//		System.out.println("factor of number "+n+"="+fact);

		System.out.println(isprime(23));
	}

}
