package Interviewprogram;
/*Write a Java program to check if a vowel is present in a string.*/
public class Vowel {
	public static boolean Vowels(String ch1)
    {
        return ch1.toLowerCase().matches(".*[aeiou].*");
    }
    public static void main (String[] args) {
        //Vowel v=new Vowel();
     //  Vowels("hello");
       System.out.println(Vowels("hello"));
        
    }
}

	

