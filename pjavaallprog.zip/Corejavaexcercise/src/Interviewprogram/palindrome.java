/*A palindrome number is a number that is same after reverse. For example 545, 151, 34543, 343, 171, 48984 are the 
 * palindrome numbers. It can also be a string like LOL, MADAM etc.*/
package Interviewprogram;

public class palindrome {
	

}
