package Basic;

import java.util.Scanner;

public class Rockpaper {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter shapes:");
		String r=sc.next();
		String s=sc.next();
		//String p=sc.next();
		if(r.equalsIgnoreCase("ROCK") && s.equalsIgnoreCase("scissors"))
		{
			System.out.println("rock wins");
		}
		else if(r.equalsIgnoreCase("rock") && s.equalsIgnoreCase("paper"))
		{
			System.out.println("paper wins");
			
		}
		else if(r.equalsIgnoreCase("paper")&& s.equalsIgnoreCase("scissors"))
		{
			System.out.println("scissors wins");
		}
		else
		{
			System.out.println("you loss");
		}
		
	}




}
