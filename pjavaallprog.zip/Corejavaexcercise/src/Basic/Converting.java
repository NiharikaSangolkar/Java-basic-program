package Basic;

public class Converting {
 public	static boolean Odd(char ch) 
	{
		return ((ch - '0') & 1) != 0 ?true : false;
	}

 

}
