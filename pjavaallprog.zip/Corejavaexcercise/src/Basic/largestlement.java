package Basic;

import java.util.Scanner;

public class largestlement {
	public static void main(String[] args) {
		//Scanner sc=new Scanner(System.in);
		int arr[]= {12,14,56,78};
		int max=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]<max)
			{
				max=arr[i];
				
			}
		}
		System.out.println("largest element is "+max);
		
		
		
	}

}
