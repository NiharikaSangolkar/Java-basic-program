package Basic;

import java.util.Scanner;

public class Practice {
	public static void main(String[] args) {
		//palindrome 121
		//armstrong= 153=1*1*1+5*5*5+3*3*3=153
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int num=sc.nextInt();
		int temp,rem,sum=0;
		//rev=0;
		temp=num;
		while(num>0)
		{
			rem=num%10;
			//rev=(rev*10)+rem;
			sum=sum+(rem*rem*rem);
			
			num=num/10;
			
		}
		if(temp==sum)
		{
			//System.out.println("its is palindrome");
			System.out.println("its armstrong number");
		}
		else
		{
			//System.out.println("not a palindrome");
			System.out.println("its not a plaindrome");
		}
		
		
	}

}
