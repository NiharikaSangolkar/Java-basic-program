package Basic;


public class pattern {
	 static public  void main(String []args){

		int r=5, k,j,i;

		for( i=0;i<=r;i++)
		{
		
		for(j=r-i;j>=0;j--)
		{
			System.out.print(" ");
		} 
		for(k=0;k<=i;k++)
		{
			System.out.print("* ");
		}		
	
		System.out.println();
		}
		}


}
