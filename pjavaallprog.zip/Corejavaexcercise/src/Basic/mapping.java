package Basic;

import java.util.HashMap;
import java.util.Map;

public class mapping {
	public static void main(String[] args) {
		HashMap<String, Integer> h1=new HashMap<String,Integer>();
		HashMap<String, Integer> h2=new HashMap<String,Integer>();
		//HashMap<String, Integer> h3=new HashMap<String,Integer>();
		h1.put("riya", 101);
		h1.put("piya", 106);
		h1.put("priya", 104);
		h1.put("raya", 103);
		System.out.println("h1:"+h1);
		h2.put("ram", 102);
		h2.put("rahul", 108);
		h2.put("vinit", 105);
		h2.put("ravi", 104);
		h2.put("raj", 105);
		h2.put("ram", 106);
		System.out.println("h2:"+h2);
		
		h2.putAll(h1);
		System.out.println("coping elemet:"+h2);
		
		
		
		
	}

}
