package Basic;

public class Student {
	int id1;
	String name1,coll1;
	@Override
	public String toString() {
		return "Student [id1=" + id1 + ", name1=" + name1 + ", coll1=" + coll1 + "]";
	}
	public Student(int id1, String name1, String coll1) {
		super();
		this.id1 = id1;
		this.name1 = name1;
		this.coll1 = coll1;
	}
	
	
	
	public static void main(String[] args) {
		Student s=new Student(1, "riya", "abc");
		System.out.println(s);
		
	}

}
