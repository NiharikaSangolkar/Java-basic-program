package Basic;

import java.util.Scanner;

public class Binarystring {
   public static String binary(String a,String b) 

	{
		int num1=Integer.parseInt(a);
		int num2=Integer.parseInt(b);
		int sum=num1+num2;
		String result=Integer.toBinaryString(sum);
		System.out.println(result);
		return result;
	}
	public static void main(String[] args) {
		
		// Binarystring b=new Binarystring();
           binary("010101","1010101");
		
		
		 
	}

}
