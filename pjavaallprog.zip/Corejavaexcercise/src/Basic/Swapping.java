package Basic;

public class Swapping {
	public static void main(String[] args) {
		int m=4;
		int n=5;
		int t;
		System.out.println("original value of m "+m+" original values of n "+n);
		t=m;
		m=n;
		n=t;
		System.out.println("swappig values of m "+m+" swapping values of n "+n);
	}

}
