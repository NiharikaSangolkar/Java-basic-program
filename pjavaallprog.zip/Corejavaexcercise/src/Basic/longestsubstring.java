package Basic;

public class longestsubstring {
	public static String issubpalindrome(String s,int i,int j)
	{
		if(i>j)
			return null;
		while(i>=0 && j<s.length()&& s.charAt(i)==s.charAt(j))
		{
			i--;
			j++;
		}
		return s.substring(i+1, j);
		
	}
	public static String ispalindrome(String s)
	{
		if(s==null)
		return null;
		String longest=s.substring(0, 1);
		for(int k=0;k<s.length()-1;k++)
		{
			String palindrome=issubpalindrome(s, k, k);
			if(palindrome.length()>longest.length())
			{
				palindrome=longest;
			}
			palindrome=issubpalindrome(s, k, k+1);
			if(palindrome.length()>longest.length())
			{
				palindrome=longest;
			}
			
		}
		
		return longest;
	}
	
	
	
 public static void main(String[]args) {
	 //System.out.println(longestpalindrome("bba"));
	 System.out.println(ispalindrome("abb"));
	
}
 
}
