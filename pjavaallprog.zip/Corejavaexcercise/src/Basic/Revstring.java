package Basic;

import java.util.Scanner;

public class Revstring {
	public static void main(String[] args) {
	  Scanner sc=new Scanner(System.in);
	  String str=sc.nextLine();
	  String rev="";
	  int strlen=str.length();
	  for(int i=(strlen-1); i>=0; i--)
	  {
		  rev=rev+str.charAt(i);
	  }
	  if(str.equals(rev))
	  {
		  System.out.println("reverse String:"+rev);
	  }
	  else
	  {
		  System.out.println("not rev");
	  }
	}

	

}
