package Basic;

import java.util.Scanner;

public class Palindrome {
	public static void main(String[]args)
	{
		int r,temp,rev=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		temp=n;
		while(n>0)
		{
			r=n%10;
			rev=(rev*10)+r;
			n=n/10;
			
		}
		if(temp==rev)
		{
			System.out.println("its palindrome");
		}
		else
		{
			System.out.println("not palindrome");
		}
	}

}
