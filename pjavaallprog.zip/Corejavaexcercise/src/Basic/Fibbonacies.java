/*The Fibonacci series is a series of elements where, 
  the previous two elements are added to get the next element, starting with 0 and 1. 
  In this article, we will learn how to print Fibonacci Series in Java up to the 
  N term where N is the given number.

Examples of Fibonacci Series in Java
Input: N = 10 
Output: 0 1 1 2 3 5 8 13 21 34 
Here first term of Fibonacci is 0 and second is 1, so that 3rd term = first(o) + second(1) 
etc and so on.*/
package Basic;

import java.util.Scanner;

public class Fibbonacies {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter input:");
		int n=sc.nextInt();
		int n1=0,n2=1,counter=0,n3;
		// Iterate till counter is N
		while(counter<n)
		{
			System.out.println(n1+" ");
			n3=n1+n2;
			//swapping
			n1=n2;
			n2=n3;
			counter+=1;
		}
		
	}

}
