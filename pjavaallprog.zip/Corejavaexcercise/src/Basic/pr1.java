/*Write a Java program to divide two numbers and print them on the screen.
Test Data :
50/3
Expected Output :
16  and 25*5=125*/

package Basic;

import java.util.Scanner;

public class pr1 {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter 2 nums:");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		System.out.println(n1+"/"+n2+"="+(n1/n2));
		System.out.println(n1+"*"+n2+"=" +(n1*n2));
	}



}
