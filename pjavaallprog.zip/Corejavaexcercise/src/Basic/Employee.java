/*Write a program by creating an 'Employee' class having the following functions and print the final salary.

1 - 'getInfo()' which takes the salary, number of hours of work per day of employee as parameters
2 - 'AddSal()' which adds $10 to the salary of the employee if it is less than $500.
3 - 'AddWork()' which adds $5 to the salary of the employee if the number of hours of
 work per day is more than 6 hours.*/
package Basic;

import java.util.Scanner;

public class Employee {
	
  public void getInfo(){

	Scanner in = new Scanner(System.in);

	System.out.println("Enter your salary");

	double salary = in.nextDouble();

	System.out.println("Enter the no.of working hours");

	int hours = in.nextInt();

	}

public void	AddSal()

	{

	System.out.println("enter salary");
	Scanner sc=new Scanner(System.in);
	double sal=sc.nextDouble();

	if(sal < 500)

	sal = sal + 10;

	System.out.println("Salary: " + sal);

	}

public void AddWork()

	{

	Scanner sc=new Scanner(System.in); //
    System.out.println("enter hours");
	int hours=sc.nextInt();
	 int sal=5000;

	if(hours > 6)

	sal =sal + 5;

	System.out.println("Salary: " + sal);

	}

	public static void main(String[]args)

	{

	Scanner in = new Scanner(System.in);

	Employee obj = new Employee();

	obj.getInfo();

	obj.AddSal();

	obj.AddWork();

	}

	

	}

