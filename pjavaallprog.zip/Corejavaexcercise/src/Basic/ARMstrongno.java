/*Input:153
Output: Yes
153 is an Armstrong number.
1*1*1 + 5*5*5 + 3*3*3 = 153

*/
package Basic;

import java.util.Scanner;

public class ARMstrongno {
	public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
		System.out.println("enter number:");
		int n=sc.nextInt();
		int temp=n,p=0,r;
		while(n>0)
		{
			r=n%10;
			p=p+(r*r*r);
			n=n/10;
			
		}
		if(temp==p)
		{
			System.out.println("its armstrong number");
		}
		else
		{
			System.out.println("its not armstrong number");
		}
	}

}
