package Basic;

import java.util.Arrays;
import java.util.Comparator;

public class longeststring {
	public static void main(String[] args) {
		 String[] names = {"sumit", "karan", "GainJavaKnowledge", "Vivek", "MontyNewMemeberOnThisGroup"};
		 System.out.println(Arrays.toString(names));

	       // String longetsString = Arrays.stream(names).max(Comparator.comparingInt(String::length)).get();

        //String longetsString = Arrays.stream(names).reduce((x,y)-> x.length() > y.length()? x : y).get();
		 String longesstring=Arrays.stream(names).max(Comparator.comparing(String::length)).get();
	        System.out.println("Longest String : "+longesstring);
	}

}
