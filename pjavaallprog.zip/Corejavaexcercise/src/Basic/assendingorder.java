package Basic;

import java.util.Arrays;
import java.util.Collections;

import Abstractionprademo.Animalmain;

//import Abstractionprademo.Animalmain;

public class assendingorder {
	/*public static void main(String[] args) {
	  Integer arr[]=  new Integer[]{12,34,56,81,55,76,57};
		System.out.println("original array order: "+Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println("arrys in ascending order: "+Arrays.toString(arr));
		Arrays.sort(arr,Collections.reverseOrder());
		System.out.println("descending order:"+(Arrays.toString(arr)));
		
	}*/
	    static void toLower(String S) {
	        System.out.println(S);
	        System.out.println(S.toLowerCase());
	        // code here
	        
	 }
	   public static void main(String[] args) {
		toLower("ADFGee");
	}

}
