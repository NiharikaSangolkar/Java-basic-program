package Basic;

import java.util.Scanner;

public class ptr {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number:");
		int n=sc.nextInt();
		//int temp,r,sum=0;
		int count=0,n1=0,n2=1,n3;
		//temp=n;
	/*	while(n>0)
		{
			r=n%10;
			//sum=(sum*10)+r; //palindrome logic
			sum=sum+(r*r*r);
			n=n/10;
			
			
		}
		if(temp==sum)
		{
			System.out.println("its armstrong");
			//System.out.println("its palindrome");
		}
		else
		{
			System.out.println("not ars");
			//System.out.println("not pl");
		}*/
		System.out.println("fibbonaccies series:");
		while(count<n)
		{
			System.out.println(n1+"");
			n3=n1+n2;
			n1=n2;
			n2=n3;
			count+=1;
		}
		
		
	}

}
