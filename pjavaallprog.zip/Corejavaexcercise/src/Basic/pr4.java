/*Write a Java program to compute the distance between two points on the earth's surface.

Distance between the two points [ (x1,y1) & (x2,y2)]
d = radius * arccos(sin(x1) * sin(x2) + cos(x1) * cos(x2) * cos(y1 - y2))
Radius of the earth r = 6371.01 Kilometers

Test Data:
Input the latitude of coordinate 1: 25
Input the longitude of coordinate 1: 35
Input the latitude of coordinate 2: 52.5
Input the longitude of coordinate 2: 35.5*/

package Basic;

import java.util.Scanner;

public class pr4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter latitude of coordinate 1:");
		double lat1=sc.nextDouble();
		System.out.println("enter langitude of coordinate 1:");
		double lan1=sc.nextDouble();
		System.out.println("enter latitude of coordinate 2:");
		double lat2=sc.nextDouble();
		System.out.println("enter langitude of coordinate 2:");
		double lan2=sc.nextDouble();
		System.out.println("the distance between two points on the earth's surface:"+ distance_between_latlong(lat1, lan1,lat2, lan2 ) +
				"km/hr");
	}

	public static double  distance_between_latlong(double lat1, double lan1, double lat2, double lan2) {
		lat1=Math.toRadians(lat1);
		lan1=Math.toRadians(lan1);
		lat2=Math.toRadians(lat2);
		lan2=Math.toRadians(lan2);
		double earthRadius=6371.01;
		return earthRadius * Math.acos(Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1) * Math.cos(lat2) * Math.cos(lan1 - lan2));
	}
}

	


