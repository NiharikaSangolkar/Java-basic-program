package Basic;

import java.util.Scanner;

public class Revpalstr {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string:");
		String str=sc.nextLine();
		//String str="nitin";
		String rev="";
		int strlen=str.length();
		for(int i=(strlen-1);i>=0;i--)
		{
			rev+=str.charAt(i);
		}
		if(str.equals(rev))
				{
			      System.out.println("its is palindrome:"+rev);
				}
		else
		{
			System.out.println("not rev");
		}
		
	}


}
