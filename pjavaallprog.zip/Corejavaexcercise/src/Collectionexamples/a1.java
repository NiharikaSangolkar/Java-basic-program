package Collectionexamples;

import java.util.ArrayList;
import java.util.Collections;

public class a1 {
	
	    public static void main(String[] args) {
	    
	    //System.out.println("Hello Codiva");
	    ArrayList<String> as=new ArrayList<String>();
	    as.add("black");
	    as.add("white");
	    as.add("purpule");
	    System.out.println("before the shuffle:"+as);
	    Collections.shuffle(as);
	    System.out.println("after the shuffle:"+as);
	    
	    
	  }

	    
	}


