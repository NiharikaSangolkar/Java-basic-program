package Collectionexamples;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
/*
 Input: v1={1,2,3,4,5}

Output: 5

Input: v2={7,50,0,67,98}

Output: 98 
  
 
 * */
import java.util.Vector;

public class c1 {
	public static void main(String[] args) {
		Vector<Integer> v=new Vector<Integer>();
		v.add(12);
		v.add(2);
		v.add(3);
		v.add(4);
		v.add(5);
		System.out.println("v:"+v);
		
		System.out.println("maximum integer number in array:"+Collections.max(v));
   
		ArrayList<String> al=new ArrayList<String>();
		al.add("blue");
		al.add("pink");
		System.out.println();
	
	
	}

}
