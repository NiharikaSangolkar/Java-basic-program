package Encapsulationprademo;

public class persondata {
	private String name,country;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public static void main(String[] args) {
		persondata p=new persondata();
		p.setName("RUIXXFCT");
		p.setCountry("INDIA");
		p.setAge(56);
		System.out.println("name:"+p.getName()+" country:"+p.getCountry()+" age:"+p.getAge());
		
	}

}
