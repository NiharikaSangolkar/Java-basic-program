/*Write a Java program to create a class called Circle with a 
 * private instance variable radius. Provide public getter and 
 * setter methods to access and modify the radius variable.
 * However, provide two methods called calculateArea() and
 * calculatePerimeter() that return the calculated
area and perimeter based on the current radius value.*/
package Encapsulationprademo;

import java.util.Scanner;

public class Circle {
	private double radius;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
	public void calculateArea()
	{
		double a=3.14*radius*radius;
		System.out.println("Area of circle: "+a);
	}
	public void calculatePerimeter()
	{
		double p=2*3.14*radius;
		System.out.println("Perimeter of circle: "+p);
	}
	public static void main(String[] args) {
		Circle c=new Circle();
		/*Scanner sc=new Scanner(System.in);
		System.out.println("enter radius:");
		c.setRadius(sc.nextDouble());*/
		c.setRadius(12);
		System.out.println("Radius of circle: "+c.getRadius());
		c.calculateArea();
		c.calculatePerimeter();
	}

	

}
