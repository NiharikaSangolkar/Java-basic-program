/*Write a Java program to create a class called Employee 
 * with private instance variables employee_id, employee_name,
 *  and employee_salary. Provide public getter and setter methods 
 *  to access and modify the id and name variables, 
 * but provide a getter method for the salary variable that returns a formatted string.*/
package Encapsulationprademo;

public class Employee { 
	private int employee_id;
	private String employee_name;
	 private double employee_salary;
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public double getEmployee_salary() {
		return employee_salary;
	}
	public void setEmployee_salary(double employee_salary) {
		this.employee_salary = employee_salary;
	}
	 public static void main(String[] args) {
		 Employee e=new Employee();
		 e.setEmployee_id(123);
		 e.setEmployee_name("PRIYA");
		 e.setEmployee_salary(345678);
		 String str=Double.toString(e.employee_salary);
		 System.out.println("Employee Id:"+e.getEmployee_id());
		 System.out.println("Employee Name:"+e.getEmployee_name());
		 System.out.println("Employee Salary $"+str);
		
	}
	
	}




