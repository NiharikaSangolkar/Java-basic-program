/*Write a Java program to create a class called BankAccount with private 
 * instance variables accountNumber and balance. 
 * Provide public getter and setter methods to access and modify these variables.*/
package Encapsulationprademo;

import java.util.Scanner;

public class BankAccount {
	private double accountnumber,balance;

	public double getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(double accountnumber) {
		this.accountnumber = accountnumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		BankAccount b=new BankAccount();
		System.out.println("enter account number:");
		b.setAccountnumber(sc.nextInt());
		b.setBalance(450000);
		System.out.println("your account number:"+b.getAccountnumber());
		System.out.println("your balance: "+b.getBalance());
	}

	
}
