/*Problem statement: Sort the given array in ascending order such that elements will be arranged from smallest to largest. Consider an illustration below:

Let the original array be as follows: 

-5	-9	8	12	1	3
Array generated after sorting the above array is as follows: 

-9	-5	1	3	8	12*/
package Arrayprogram;

import java.util.Arrays;

public class A12 {
	public static void main(String[] args) {
		Integer arr[]= {-5,	-9,	8,12,1,3};
		System.out.println("arrays:"+Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println("the given array in ascending order:  "+Arrays.toString(arr));
		
	}

}
