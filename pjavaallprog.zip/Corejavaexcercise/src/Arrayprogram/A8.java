//Write a Java program to find the index of an array element.
package Arrayprogram;

public class A8 {
	public static int findindex(int arr1[],int t)
	{
		if(arr1==null)
			return -1;
		int len=arr1.length;
		int i=0;
		while(i<len)
		{
			if(arr1[i]==t)
			{
				return i;
				
			}
			else
			{
				i+=1;
			}
		}
		return -1;
	}


	public static void main(String[] args) {
		int arr[]= {1,3,45,6,7,9,0,5,4};
		System.out.println("postion of index 45: "+findindex(arr,45));
		System.out.println("postion of index 5: "+findindex(arr,5));
		
		
	}

}
