/*Given two given arrays of equal length, the task is to find if given arrays are equal or not. Two arrays are said to be equal if both of them contain the same set of elements and in the same order. 

Note: If there are repetitions, then counts of repeated elements should be the same for two arrays to be equal.

Examples:

Input  : arr1[] = {1, 2, 5, 4, 0};
         arr2[] = {1, 2, 5, 4, 0}; 
Output : Yes

Input  : arr1[] = {1, 2, 5, 4, 0, 2};
         arr2[] = {2, 4, 5, 0}; 
Output : No*/
package Arrayprogram;

import java.util.Arrays;

public class A13 {
	public static void main(String[] args) {
		Integer arr1[]={1, 2, 5, 4, 0};
		Integer arr2[] = {1, 2, 5, 4, 0};
	    boolean result=	Arrays.equals(arr1, arr2);
		if(result==true)
		{
			System.out.println("arrays are equal");
		}
		else
		{
			System.out.println("arrays are not equal");
		
		}
	}

}
