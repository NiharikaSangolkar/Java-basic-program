/* Write a Java program to find the number of days in a month.

Test Data
Input a month number: 2
Input a year: 2016
Expected Output :
February 2016 has 29 days*/
package Arrayprogram;

import java.util.Scanner;

public class cal {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter a month number:");
		int m=s.nextInt();
		//int day=s.nextInt();
		System.out.println("enter year:");
		int y=s.nextInt();
		if(m==1)
		{
			System.out.println("jan "+y+"has 31 days.");
		}
		else if(m==2)
		{
			
			System.out.println("February "+y+"has 29 days");
		}
		else if(m==3)
		{
			System.out.println("march "+y+"has 31 days");
		}
		else if(m==4)
		{
			System.out.println("april "+y+"has 30 days");
		}
		else if(m==5)
		{
			System.out.println("may "+y+"has 31 days");
		}
		else if(m==6)
		{
			System.out.println("june "+y+"has 31 days");
		}
		else if(m==7)
		{
			System.out.println("july "+y+"has 31 days");
		}
		else if(m==8)
		{
			System.out.println("aug "+y+"has 31 days");
		}
		else if(m==9)
		{
			System.out.println("sep "+y+"has 30 days");
		}
		
		
		
		
		
		
		
			
			
		

		
	}

}
