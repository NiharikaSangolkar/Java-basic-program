package Arrayprogram;

import java.util.Arrays;

public class A14 {
	public static void main(String[] args) {
		int[] arr1= {1,2,3,4,5};
		int [] arr2= {5,6,7,8,9};
		int a=arr1.length;
		int b=arr2.length;
		int c=a+b;
		int c1[]=new int[c];
		System.arraycopy(arr1, 0, c1, 0, a);
		System.arraycopy(arr2, 0, c1, a, b);
		System.out.println(Arrays.toString(c1));
		
	}

}
