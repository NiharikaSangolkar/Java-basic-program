package Arrayprogram;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class A10 {
	public static void main(String[] args) {
		Integer arr[]=new Integer[] {2,3,45};
		int k=1;
		System.out.println("original arrays:");
		System.out.println(Arrays.toString(arr));
		/*Arrays.sort(arr);
		System.out.println("smallest value:");*/
		
		Arrays.sort(arr,Collections.reverseOrder());
		System.out.println("largest value:");
		for(int i=0;i<k;i++)
		{
			System.out.println(arr[i]);
			
		}
		
		
	}
	

}
