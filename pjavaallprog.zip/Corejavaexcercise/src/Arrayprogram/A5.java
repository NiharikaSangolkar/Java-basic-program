/*Write a Java program that finds numbers greater than the average of an array.

Expected Output:
Original Array:
[1, 4, 17, 7, 25, 3, 100]
The average of the said array is: 22.0
The numbers in the said array that are greater than the average are:
25
100*/
package Arrayprogram;

import java.util.Arrays;

public class A5 {
	public static void main(String[] args) {
		Integer arr[]=new Integer[] {-2,1,-3, 4, -1, 2, 1,-5,4};
		int sum=0;
		System.out.println("original intere array:");
		System.out.println(Arrays.toString(arr));
		for(int i=0;i<arr.length;i++) {
			sum+=arr[i];
			//System.out.println(sum);
		}
		System.out.println("total sum"+sum);
		


		}
		
			
			
	}


