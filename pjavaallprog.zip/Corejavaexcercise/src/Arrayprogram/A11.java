/*Sort the given array in descending order, i.e., arrange the elements from largest to smallest. 

Example:

Input :Array = {2, 6, 23, 98, 24, 35, 78}
Output:[98, 78, 35, 24, 23, 6, 2]

Input :Array = {1, 2, 3, 4, 5}
Output:[5, 4, 3, 2, 1]*/
package Arrayprogram;
import java.util.*;

public class A11 {
	public static void main(String[] args) {
		Integer arr[]=new Integer[]{2, 6, 23, 98, 24, 35, 78};
		//System.out.println("arra");
		System.out.println("Arrays= "+Arrays.toString(arr));
		Arrays.sort(arr,Collections.reverseOrder());
		
		System.out.println("the given array in descending order:");
		System.out.println(Arrays.toString(arr));


	}

}
