//assending ordere
package Arrayprogram;
import java.util.*;
public class A2 {
	public static void main(String[] args) {
		Integer arr[]=new Integer[]{1,20,33,46,78,89,3};
		int k=3;
		System.out.println("orginal strings are:");
		System.out.println(Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println("smallest string");
		
		for(int i=0;i<3; i++)
		{
			
			System.out.print(arr[i]+" ");
		}
		
		
	}

}
