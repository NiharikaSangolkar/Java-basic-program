package Arrayprogram;

public class A15 {
	public static int findindex(int arr[],int item)
	{
		if(arr==null)
			return -1;
		
		int len=arr.length;
		int i=0;
		while(i<len) {
	
			if(arr[i]==item)
			{
				return i;
			}
			else
			{
				i+=1;
			}
			
		}
		
		return -1;
	}
	public static void main(String[] args) {
		int arr[]= {1,2,3,4,5};
		System.out.println( "arrays of 5 th index is:"+findindex(arr, 5));
		
	}

}
