package Arrayprogram;

public class A6 {
public static void main(String[] args) {
	Integer arr[]=new Integer[] {1,2,3,45,67,78};
	int sum=0;
	for(int i=0;i<arr.length;i++)
	{
		sum+=arr[i];
		
	}
	System.out.println(sum);
	double avg=sum/(arr.length);
	System.out.println(avg+"avg");
	
	
}
}
