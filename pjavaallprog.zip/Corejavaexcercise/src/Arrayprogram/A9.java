package Arrayprogram;

import java.util.Arrays;

public class A9 {
	public static boolean check(int arr[],int checkvalue)
	{
		for(int i:arr)
		{
			if(i==checkvalue)
			{
				return true;
			}
		}
		return false;
	//	System.out.println("Is " +checkvalue
               // + " present in the array: " + i);
		
	
		
	}
	public static void main(String[] args) {
		int arr[]= {1,2,3,4,5,6,7};
		int checkvalue=7;
		System.out.println("arrays of original string:"+Arrays.toString(arr));
		
		System.out.println(check(arr, checkvalue));
		
		
	}

}
