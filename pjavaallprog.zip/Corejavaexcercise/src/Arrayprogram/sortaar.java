package Arrayprogram;

import java.util.Arrays;

public class sortaar {
	public static void main(String[] args) {
		int a[]= {13,45,67,89,56,76};
		Arrays.sort(a);
		for(int i=a.length-1;i>=0;i--)
		{
			System.out.print(a[i]+a[i]);
		}
		//System.out.println(Arrays.sort(a));
	}

}