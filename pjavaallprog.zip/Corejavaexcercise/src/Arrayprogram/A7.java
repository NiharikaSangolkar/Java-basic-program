//Write a Java program to test if an array contains a specific value.
package Arrayprogram;

public class A7 {
	public static boolean contains(int arr[],int item)
	{
		for(int n:arr)
		{
			if(n==item)
			{
				return true;
			}
		}
		return false;
	}
	public static void main(String[] args) {
		int a[]= {1,2,3,4,5,6,67,8};
		System.out.println(contains(a,76));
		System.out.println(contains(a,8));
	}
}
