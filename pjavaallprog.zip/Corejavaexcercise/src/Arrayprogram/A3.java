package Arrayprogram;

import java.util.Arrays;
import java.util.Collections;

public class A3 {
	public static void main(String[] args) {
		String arr[]=new String[] {"happy","diwali","to","everyone"};
		int k=3;
		Arrays.sort(arr,Collections.reverseOrder());
		for(int i=0;i<3;i++)
		{
			System.out.println(arr[i]+" ");
		}
	}

}
