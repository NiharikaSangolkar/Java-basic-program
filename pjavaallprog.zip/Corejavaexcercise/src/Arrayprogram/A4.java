/*Write a Java program that finds numbers greater than the average of an array.

Expected Output:
Original Array:
[1, 4, 17, 7, 25, 3, 100]
The average of the said array is: 22.0
The numbers in the said array that are greater than the average are:
25
100*/
package Arrayprogram;

import java.util.Arrays;

public class A4 {
	public static void main(String[] args) {
		Integer arr[]=new Integer[] {1, 4, 17, 7, 25, 3, 100};
		int sum=0;
		System.out.println("originals number:");
		System.out.println(Arrays.toString(arr));
		
		for(int i=0;i<arr.length;i++)
		{
			sum+=arr[i];
			System.out.println(sum);
		}
		double avg=sum/arr.length;
		System.out.println(avg+"average");
		System.out.println("The numbers in the said array that are greater than the average are:");
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>arr.length)
			{
			System.out.println(arr[i]+" ");
			}
		}
		
			
			
	}

}
