package Basicmath;

import java.util.Scanner;

public class practice {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		int n=sc.nextInt();
		//int temp,r,sum=0;
		//temp=n;
		int n1=0,n2=1,n3,r, c=1;
		System.out.println("fibbonacies series");
		while(c<n)
		{
			/*r=n%10;
			sum=sum+(r*r*r);
			n=n/10;*/
			System.out.println(n1+"");
			n3=n1+n2;
			n1=n2;
			n2=n3;
			c+=1;
			
			
		}
		
	}

}
