package Basicmath;

import java.util.Scanner;

public class facorial {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//4=4*3*2*1
		System.out.println("enter number");
		int n=sc.nextInt();
		int fact=1;
		for(int i=1;i<=n;i++)
		{
			fact*=i;
			
		}
		System.out.println("factorial of "+n+"!="+fact);
	}

}
