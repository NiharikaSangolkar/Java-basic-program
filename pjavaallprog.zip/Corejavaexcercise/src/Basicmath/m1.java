package Basicmath;

public class m1 {
	public static void main(String[] args) {
		System.out.println("min value:"+Math.min(5, 6));
		System.out.println("max value:"+Math.max(7, 9));
		System.out.println((int)Math.random()*100);
		
	}

}
