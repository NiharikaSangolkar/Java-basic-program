package Basicmath;

import java.util.Scanner;

public class Automorphic {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number:");
		int n=sc.nextInt();
		int sqr=n*n;
		String num=Integer.toString(n);
		String square=Integer.toString(sqr);
		if(square.endsWith(num))
		{
			System.out.println("it is atmoprhic:"+n);
		}
		else
		{
			System.out.println("it is  not atmoprhic:"+n);
		}
	}

}
