package practice;

import java.util.Arrays;

public class arrlong {
	public static void main(String[] args) {
		int arr[]= {12,13,67,78};
		Arrays.sort(arr);
		System.out.println("minimum value:"+arr[0]);
		System.out.println("maximum value:"+arr[arr.length-1]);
	}

}
