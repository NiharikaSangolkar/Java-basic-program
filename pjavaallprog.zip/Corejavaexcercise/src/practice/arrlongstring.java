package practice;

import java.util.Arrays;
import java.util.Comparator;

public class arrlongstring {
	public static void main(String[] args) {
		String arr[]= {"hello","hellloooooo","usgdyustdututyudtu"};
		String longest=Arrays.stream(arr).max(Comparator.comparing(String::length)).get();
		System.out.println("maximum string:"+longest);
		String smallest=Arrays.stream(arr).min(Comparator.comparing(String::length)).get();
		System.out.println("maximum string:"+smallest);
	}

}
