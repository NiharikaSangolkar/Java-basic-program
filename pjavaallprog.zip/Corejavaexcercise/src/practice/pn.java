package practice;

import java.util.Scanner;

public class pn {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number:");
		int n=sc.nextInt();
		if(n>0)
		{
			System.out.println(n+"number is postive");
			
		}
		else
		{
			System.out.println(n+"number is negative");
		}
	}

}
