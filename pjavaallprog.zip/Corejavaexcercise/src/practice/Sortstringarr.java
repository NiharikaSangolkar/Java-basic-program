package practice;

import java.util.Arrays;

public class Sortstringarr {
	public static void main(String[] args) {
		String arr[]= {"hihijoi","hi","helloooooo"};
		String arr1[]= {"hhgyg","ghy","helloooooo"};
		//System.out.println("marge array:"+Arrays.toString(arr.length));
		
//		Arrays.sort(arr);
//		//System.out.println(arr);
//		for(int i=0;i<=arr.length;i++)
//		{
//			System.out.println(arr[i]);
//		}
		
	}

}
