package practice;

import java.util.Arrays;

public class revarray {
	public static void main(String[] args) {
		int arr[]= {12,355,67,89};
		//Arrays.sort(arr);
		for(int i=arr.length-1;i>=0;i--)
		{
			System.out.print(arr[i]);
		}
	}

}
