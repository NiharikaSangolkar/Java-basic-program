package practice;

import java.util.Scanner;

public class armstrong {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		//System.out.println("enter the number of digit:");
		int d=sc.nextInt();
		int sum=0,rem,temp=n;
		while(n>0)
		{
			rem=n%10;
			sum=(int)(sum+Math.pow(rem, d));
			n=n/10;
			
			
		}
		if(temp==sum)
		{
			System.out.println("it is armstrong");
		}
		else
		{
			System.out.println("it  is not  armstrong");
			
		}
		
	}

}
