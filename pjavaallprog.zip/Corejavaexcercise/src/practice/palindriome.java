package practice;

import java.util.Scanner;

public class palindriome {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number:");
		int n=sc.nextInt();
		int rev=0,temp=n;
		while(n>0)
		{
			rev=(rev*10)+n%10;
			n=n/10;
			
		}
		if(temp==rev)
		{
			System.out.println("its palindrome"+temp);
		}
		else
		{
			System.out.println("its not paindrome"+temp);
		}
	}

}
