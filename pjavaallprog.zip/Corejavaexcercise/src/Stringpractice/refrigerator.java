/*Write a program to find the length of the string "refrigerator".and convert the string into ower case and upper case.
*/
package Stringpractice;

public class refrigerator {
	public static void main(String[] args) {
		String s="refrigerator";
		System.out.println(s.length());
		System.out.println(s.toLowerCase());
		System.out.println(s.toUpperCase());
	}

}
