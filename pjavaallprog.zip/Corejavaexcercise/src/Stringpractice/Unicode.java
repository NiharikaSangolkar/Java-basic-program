package Stringpractice;

public class Unicode {
	public static void main(String[] args) {
		String s="tom and jerry";
		System.out.println("given string "+s);
		int v1=s.codePointAt(0);
		int v2=s.codePointAt(7);
		int v3=s.codePointCount(1, 8);
		System.out.println("Character :"+s.charAt(0)+"\nUnicode Point : " + v1);
		System.out.println("Character :"+s.charAt(6)+"\nUnicode Point : " + v2);
		System.out.println("charcter1: "+s.charAt(1)+" charcter7 "+s.charAt(8)+" codepointcount: "+v3);
	    System.out.println(s.toUpperCase());
	    String v=s.replace('a','b');
	    System.out.println(v);
	}

}
