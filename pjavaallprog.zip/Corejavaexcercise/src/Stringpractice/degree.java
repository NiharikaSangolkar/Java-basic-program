/*Create a class 'Degree' having a method 'getDegree' that prints "I got a degree" if the user
 *  enters "yes" on asking a question "you have a degree or not". 
 * Call the method by creating an object of class*/
package Stringpractice;

import java.util.Scanner;

public class degree {
	public void getdegree()
	{
		System.out.println("do you have degree or not?");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String r="yes";
		if(s.equalsIgnoreCase(r))
		{
			System.out.println("I got degree");
			
		}
		else
		{
			System.out.println("I can't got a degree");
		}
		
	}
	public static void main(String[] args) {
		degree d=new degree();
		d.getdegree();
	}

}
