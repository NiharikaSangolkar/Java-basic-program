/*Write a program to check if the letter 'e' is present in the word 'Umbrella'.
*/
package Stringpractice;

public class containsprob {
	public static void main(String[] args) {
		String s="Umbrella";
		System.out.println(s.contains("e"));
		
	}
	

}
