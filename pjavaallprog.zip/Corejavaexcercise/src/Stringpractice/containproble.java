/*1.Write a program to check if the word 'orange' is present in the "This is orange juice".
*/
package Stringpractice;

public class containproble {
	public static void main(String[] args) {
		String s="this is orange juice";
		System.out.println(s.contains("orange"));
	}

}
