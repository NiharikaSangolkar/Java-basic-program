package Stringpractice;

public class p1 {
	//string are mutable
	public static void main(String[] args) {
		String n="hfkfkg";
		System.out.println(n.charAt(3));//position specified
		System.out.println(n.length());//string length
		String name="chiku";
		String name1=name.replace('u', 's');// replace word
		System.out.println(name1);
		System.out.println(name);
		//substring
		String subsr="Ram and Lakhan";
		System.out.println(subsr.subSequence(3, 7));// checking char sequence
		System.out.println(name.contains("i"));
		
		
	}
	



}
