package Stringpractice;

import java.util.Scanner;

public class Stringcompare {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first string:");
		String s1=sc.next();
		System.out.println("enter second string:");
		String s2=sc.next();
		int l1=s1.length();
		int l2=s2.length();
		if(l1>l2)
		{
			System.out.println(s1 +" first is greater");
		}
		else {
			System.out.println(s2 +" second is greater");
		}
	}

}
