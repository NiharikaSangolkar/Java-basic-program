package Catsing;

public class c1 {
	public static void main(String[] args) {
		double price=100.0;
		double finalprice=price+18;// implict casting
		//in implict casting can store the value small variable into big variable
		System.out.println(finalprice);
		//explicit casting
		//exactly opposite of implict fun
		int p=100;
		int fp=p+(int)18.17;
		System.out.println(fp);
		
	}

}
