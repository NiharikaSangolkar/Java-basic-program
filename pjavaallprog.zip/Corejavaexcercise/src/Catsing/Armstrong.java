package Catsing;

import java.util.Scanner;

/* 153= 1*1*1+5*5*5+3*3*3
 * =1+125+27
 */
public class Armstrong {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number:");
		int n=sc.nextInt();
		int temp,rem,value=0;
		temp=n;
		System.out.println("enter the number of digit you entered");
	    int digit=sc.nextInt();
		
		while(n>0)
		{
			rem=n%10;
			//value=value+(rem*rem*rem);
			value=(int)(value+Math.pow(rem, digit));
			n=n/10;
		}
		if(temp==value)
		{
			System.out.println("its armstrong");
			
		}
		else {
			System.out.println("not armstrong");
		}
		
	
	}

}
