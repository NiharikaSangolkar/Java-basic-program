package Abstractionprademo;

public class Vmain {
public static void main(String[] args) {
	Car c=new Car();
	c.startEngine();
	c.stopEngine();
	Motorcycle m= new Motorcycle();
	m.startEngine();
	m.stopEngine();
	
	

 }
}
