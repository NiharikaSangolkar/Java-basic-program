package Abstractionprademo;

public class Car extends Vehicle {
	@Override
	public void startEngine() {
		System.out.println("car starting engine");
	}
	@Override
	public void stopEngine() {
		System.out.println("car stopping engine");
		
	}
	public void setcarno(int i) {
		// TODO Auto-generated method stub
		
	}
	public void setcarno(String string) {
		// TODO Auto-generated method stub
		
	}

}
