package Abstractionprademo;

public class Class {

}
