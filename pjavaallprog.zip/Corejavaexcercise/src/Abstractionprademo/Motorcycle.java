package Abstractionprademo;

public class Motorcycle extends Vehicle {
	
		@Override
		public void startEngine() {
			System.out.println("Motorcycle starting engine");
		}
		@Override
		public void stopEngine() {
			System.out.println("Motorcycle stopping engine");
			
		}

	}


