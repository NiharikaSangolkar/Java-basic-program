package Abstractionprademo;

public class Animalmain {
	public static void main(String[] args) {
		Lion l=new Lion();
		l.sound("Roar");
		Tiger t=new Tiger();
		t.sound("growls");
	}

}
