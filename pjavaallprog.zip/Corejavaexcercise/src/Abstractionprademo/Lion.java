package Abstractionprademo;

public class Lion extends Animal 
{
	@Override
	
	public void sound(String s)
	
	{
		System.out.println("Lion sound:"+s);
	}

}



