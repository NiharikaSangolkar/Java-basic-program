package Abstractionprademo;

public class Tiger extends Animal 
{
	@Override
	
	public void sound(String s)
	
	{
		System.out.println("Tiger sound:"+s);
	}


}

