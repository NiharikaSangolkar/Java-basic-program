package Collectionpractice;

import java.util.LinkedList;

public class p2 {
	public static void main(String[] args) {
		LinkedList<String>li=new LinkedList<String>();
		li.add("red");
		li.add("blue");
		li.add("pink");
		li.add("orange");
		System.out.println(li);
	}

}
