package Collectionpractice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class p3iterator {
	public static void main(String[] args) {
		ArrayList<Integer>ls=new ArrayList<Integer>();
		ls.add(45);
		ls.add(56);
		ls.add(63);
		ls.add(87);
		System.out.println(ls);
		Iterator<Integer>al=ls.iterator();
		while(al.hasNext())
		{
			System.out.println(al.next());
		}
		System.out.println();
		ListIterator<Integer>ll=ls.listIterator();
		while(ll.hasNext())
		{
			System.out.println(ll.next());
		}
		System.out.println();
		while(ll.hasPrevious())
		{
			System.out.println(ll.hasPrevious());
		}
	}

}
