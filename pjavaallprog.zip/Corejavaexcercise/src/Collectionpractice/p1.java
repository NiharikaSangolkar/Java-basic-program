package Collectionpractice;

import java.util.LinkedList;

class p1
{
	public static void main(String[] args) {
		LinkedList<Integer>l=new LinkedList<Integer>();
		l.add(2);
		l.add(34);
		System.out.println(l);
	}
}
