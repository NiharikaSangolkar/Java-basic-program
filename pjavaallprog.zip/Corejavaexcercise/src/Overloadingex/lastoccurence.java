/*Write a program to find the first and the last occurrence of the letter 'o' and 
 * character ',' in "Hello, World".
*/
package Overloadingex;

public class lastoccurence {
	public static void main(String[] args) {
		String s="Hello, World";
		System.out.println(s.lastIndexOf("o"));
		
	}

}
