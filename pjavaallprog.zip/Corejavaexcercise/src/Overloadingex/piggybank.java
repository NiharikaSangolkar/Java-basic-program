/*Suppose you have a Piggie Bank with an initial amount of $50 and you have to add some more amount to it. Create a class 'AddAmount' with a data member named 'amount' with an initial value of $50. Now make two constructors of this class as follows:
1 - without any parameter - no amount will be added to the Piggie Bank
2 - having a parameter which is the amount that will be added to the Piggie Bank
Create an object of the 'AddAmount' class and display the final amount in the Piggie Bank.
*/
package Overloadingex;

public class piggybank {
	int amount=50;
	public void piggybank()
	{
		System.out.println(amount+"$");
	}
	public void piggybank(int am)
	{
		System.out.println(am+amount+"$");
		
	}
	public static void main(String[] args) {
		piggybank p=new piggybank();
		p.piggybank();
		p.piggybank(500);
		
	}

}
