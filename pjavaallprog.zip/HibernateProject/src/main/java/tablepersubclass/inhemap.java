package tablepersubclass;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class inhemap {
	public static void main(String[] args) {
		SessionFactory sf=new Configuration().configure("hibernatesubclass.cfg.xml").buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		Employee e1=new Employee();
		e1.setName("pqr");
		regularemp e2=new regularemp();
		e2.setName("abc");
		e2.setSalary(50000);
		e2.setBonus(5);
		contracttemp e3=new contracttemp();
		e3.setName("xyz");
		e3.setContract_duration("15hours");
		session.save(e1);
		session.save(e2);
		session.save(e3);
		tx.commit();
		System.out.println("success");
		
	}

}
