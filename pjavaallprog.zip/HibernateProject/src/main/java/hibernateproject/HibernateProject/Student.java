package hibernateproject.HibernateProject;
import javax.persistence.*;
import javax.persistence.Entity;

@Entity
@Table(name="student_info")
public class Student {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	int rollno;
	
	int marks;
	@Column(name="sname")
	String name;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", marks=" + marks + ", name=" + name + "]";
	}
	

}
