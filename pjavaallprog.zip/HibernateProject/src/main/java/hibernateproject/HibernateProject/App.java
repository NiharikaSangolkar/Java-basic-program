package hibernateproject.HibernateProject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

//import java.lang.module.Configuration

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		Configuration c = new Configuration().configure().addAnnotatedClass(Student.class);
		SessionFactory sf = c.buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		Student s = new Student();
		s.setRollno(5);
		s.setName("priya");
		s.setMarks(67);
		session.save(s);
		// s.setMarks(78);
		// s=(Student)session.get(Student.class, 2);
		// System.out.println(s);

		// Student s=session.get(Student.class, 3);
		// session.delete(s);
		t.commit();
		session.close();
	}
}
