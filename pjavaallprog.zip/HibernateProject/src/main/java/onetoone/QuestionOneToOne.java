package onetoone;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class QuestionOneToOne {
	@Id
	private int qid;
	private String que;
	@OneToOne
	private AnswerOneTOone answer;
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getQue() {
		return que;
	}
	public void setQue(String que) {
		this.que = que;
	}
	public AnswerOneTOone getAnswer() {
		return answer;
	}
	public void setAnswer(AnswerOneTOone answer) {
		this.answer = answer;
	}
	
	

}
