package onetoone;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class AnswerOneTOone {
	@Id
	private int aid;
	private String ans;
	@OneToOne
	private QuestionOneToOne question;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public QuestionOneToOne getQuestion() {
		return question;
	}
	public void setQuestion(QuestionOneToOne question) {
		this.question = question;
	}
	
	

}
