package onetoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OnETOOne {
	public static void main(String[] args) {
		SessionFactory f=new Configuration().configure("hibernateone.cfg.xml").buildSessionFactory();
		Session session=f.openSession();
		Transaction t=session.beginTransaction();
		QuestionOneToOne q1=new QuestionOneToOne();
		q1.setQid(101);
		q1.setQue("what is java?");
		AnswerOneTOone a1=new AnswerOneTOone();
		a1.setAid(101);
		a1.setAns("java is a programming language.");
		a1.setQuestion(q1);
		q1.setAnswer(a1);
		QuestionOneToOne q2=new QuestionOneToOne();
		q2.setQid(102);
		q2.setQue("what is collection framework?");
		AnswerOneTOone a2=new AnswerOneTOone();
		a2.setAid(102);
		a2.setAns("API WORK WITH object in java");
		a2.setQuestion(q2);
		q1.setAnswer(a2);
		session.save(q1);
		session.save(a1);
		session.save(q2);
		session.save(a2);
		session.close();
		
		f.close();
		t.commit();
//		QuestionOneToOne data=(QuestionOneToOne)session.get(QuestionOneToOne.class, 101);
//		System.out.println(data.getQid());
//		System.out.println(data.getQue());
//		System.out.println(data.getAnswer().getAid());
//		System.out.println(data.getAnswer().getAns());
       session.close();
		
		f.close();
	
		
	}

}
