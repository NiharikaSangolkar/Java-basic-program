package embedded;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Emp {
	public static void main(String[] args) {
		SessionFactory f=new Configuration().configure("hibernateemp.cfg.xml").buildSessionFactory();
		Session session=f.openSession();
		Transaction t=session.beginTransaction();
		Address a=new Address();
		a.setArea("kharadi");
		a.setCity("pune");
		a.setPincode(411102);
		Employee e=new Employee();
		e.setEid(101);
		e.setEname("abc");
		e.setAddress(a);
		//session.save(e);
	    //t.commit();
		e=(Employee)session.get(Employee.class, 101);
		System.out.println(e.getEid());
		System.out.println(e.getEname());
		System.out.println(e.getAddress().getArea());
		System.out.println(e.getAddress().getCity());
		System.out.println(e.getAddress().getPincode());
		session.close();
		f.close();
		
		
	}

}
