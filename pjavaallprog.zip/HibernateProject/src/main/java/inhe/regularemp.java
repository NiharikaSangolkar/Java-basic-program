package inhe;
import javax.persistence.*;


@Entity

@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorValue(value="regularemp")
public class regularemp extends Emp {
	private float salary;
	private int bonus;
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	
	

}
