package manytomany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Mappingdemo {
	public static void main(String[] args) {
		SessionFactory sf=new Configuration().configure("hibernatemanytomany.cfg.xml").buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		Emp e1=new Emp();
		Emp e2=new Emp();
		e1.setId(31);
		e1.setName("abc");
		e2.setId(32);
		e2.setName("xyz");
		project p1=new project();
		project p2=new project();
		p1.setPid(12120);
		p1.setProjectName("libarary management system");
		p2.setPid(14215);
		p2.setProjectName("CHATBOT");
		List<Emp> list1=new ArrayList<Emp>();
		List<project>list2=new ArrayList<project>();
		list1.add(e1);
		list1.add(e2);
		list2.add(p1);
		list2.add(p2);
		e1.setProjects(list2);
		e2.setProjects(list2);
		p1.setEmps(list1);
		p2.setEmps(list1);
		session.save(e1);
		session.save(e2);
		session.save(p1);
		session.save(p2);
		tx.commit();
	}

}
