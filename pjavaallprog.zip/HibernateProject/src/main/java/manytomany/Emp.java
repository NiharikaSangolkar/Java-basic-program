package manytomany;

import java.util.List;

import javax.persistence.*;

@Entity
public class Emp {
	@Id
	private int id;
	private String name;
	@ManyToMany
	private List<project>projects;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<project> getProjects() {
		return projects;
	}
	public void setProjects(List<project> projects) {
		this.projects = projects;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + "]";
	}

}
