package onetoMany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Mapdemo {
	public static void main(String[] args) {
		SessionFactory f=new Configuration().configure("hibernateonetomany.cfg.xml").buildSessionFactory();
		Session session=f.openSession();
		Transaction t=session.beginTransaction();
		QuestiontoOne q=new QuestiontoOne();
		q.setQuestionId(002);
		q.setQuestion("what is java");
		Answermany a1=new Answermany();
		a1.setAnswerId(103);
		a1.setAnswers("java is a programming language");
		a1.setQuestion(q);
		Answermany a2=new Answermany();
		a2.setAnswerId(104);
		a2.setAnswers("with the help of java we can create software");
		a2.setQuestion(q);
		Answermany a3=new Answermany();
		a3.setAnswerId(105);
		a3.setAnswers("java has different types of framesworks");
		a3.setQuestion(q);
		List<Answermany> list=new ArrayList<Answermany>();
		list.add(a1);
		list.add(a2);
		list.add(a3);
		q.setAnswers(list);
		session.save(q);
		session.save(a1);
		session.save(a2);
		session.save(a3);
		t.commit();
		
		
		
	}

}
