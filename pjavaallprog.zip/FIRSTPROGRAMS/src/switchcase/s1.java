package switchcase;

import java.util.Scanner;

//week
public class s1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number of day:");
		int day=sc.nextInt();
		switch(day)
		{
		case 1:System.out.println("Monday");
		break;
		case 2:System.out.println("Tuesday");
		break;
		case 3:System.out.println("wednesday");
		break;
		case 4:System.out.println("Thrusday");
		break;
		case 5:System.out.println("Friday");
		break;
		
		}
		
	}

}
