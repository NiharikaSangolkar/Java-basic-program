package switchcase;

import java.util.Scanner;

public class gender {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	 System.out.println("enter gender(m/f)");
		char gen=sc.next().charAt(0);
		switch(gen)
		{
		case 'f':System.out.println("female");
		break;
		case 'm':System.out.println("male");
		break;
		}
	}

}
