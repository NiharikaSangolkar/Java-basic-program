package demo;

public class Variable {
	int a=45; //instanse variable
	int b;
	public void display()
	{
		b=47;
		double x=2.3; //local variable
		System.out.println(a);
		System.out.println(x);
		System.out.println(b);
	}
	public void gett(int y)
	{
	  // b=23;
		
	}

}
