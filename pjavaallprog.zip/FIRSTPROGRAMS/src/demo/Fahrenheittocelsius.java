/* formula 
 * float fahrenheit=82.0f;
   double celsius=(( 5 *(fahrenheit - 32.0)) / 9.0); */
package demo;

public class Fahrenheittocelsius {
	static float fahrenheit=82.0f;
	public static void celsius()
	{
		double celsius=((5*(fahrenheit-32.0))/9.0);
		System.out.println(celsius);
				
	}
	public static void main(String[] args)
	{
		celsius();
	}
	

}
