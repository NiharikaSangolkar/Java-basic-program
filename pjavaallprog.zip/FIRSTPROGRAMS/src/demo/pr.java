package demo;

import java.util.Scanner;

//fibo:0112358
//palindrome:121=
public class pr {
	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		System.out.println("enter number");
		int n=s.nextInt();
		//int n1=0,n2=1,n3,c=0; //fibbonaccies logic
		//
		//int r,sum=0,temp;// palindrome
	 int temp=n;
		int r,p=0;
		while(n>0)
		{
//			System.out.println(n1+"");
//			n3=n1+n2;
//			n1=n2;
//			n2=n3;
//			c=c+1; //fiboonaccies logic
			
			//palindrome
//			r=n%10;
//			sum=(sum*10)+r;
//			n=n/10; 
//			
			//armstrong
			r=n%10;
			p=p+(r*r*r);
			n=n/10;
			
			
			
			
		}
		if(temp==p)
		{
			System.out.println("its  armstrong");
		}
		else
		{
			System.out.println("not armstrong");
		}
	}
	
	

}
