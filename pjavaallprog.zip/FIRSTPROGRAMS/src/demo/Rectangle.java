//static method//
package demo;

public class Rectangle {
	static int l=45;
	static int b=12;
	public static void area()
	{
		int area=l*b;
		System.out.println(area);
		
		
	}
	public static void per()
	{
		int per=2*(l+b);
		System.out.println(per);
		
	}
	public static void main(String[]args)
	{
		area();
		per();
	}

}
