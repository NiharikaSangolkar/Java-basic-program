package demo;

import java.util.Scanner;

/*153   1+125+27*/
/* palindrome 121*/
/*fibbonaccies: 012345*/
public class Am {
	 static public void main(String[]args)
	{ 
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter the number");
		 int n=sc.nextInt();
		 int c=0,r,n1=0,n2=1,n3;
//		temp=num;
//		 while(num>0)
//		 {
//			 r=num%10;
//			 sum=sum+(r*r*r);
//			 //sum=(sum*10)+r;
//			 num=num/10;
//			 
//		 }
//		 if(temp==sum)
//		 {
//			 //System.out.println("its is armstrong");
//			 //System.out.println("its palindrome");
//		 }
//		 else
//		 {
//			 //System.out.println("it is not am");
//			 //System.out.println("it is not palindrome");
//		 }
		 System.out.println("fiboonaccies series are:");
		 while(c<n)
		 {
			 System.out.println(n1+"");
			 n3=n1+n2;
			 n1=n2;
			 n2=n3;
			 c+=1;
		 }
		 
	}
	

}
