package demo;

import java.util.Scanner;

public class revstring {
	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("enter table number:");
		int n=sc.nextInt();
		//System.out.println("enter string:");
//		String str=sc.nextLine();
//		int strlen=str.length();
//		String revstr="";
//		for(int i=(strlen-1);i>=0; --i)
//		{
//			revstr+=str.charAt(i);
//			
//		}
//		if(str.equalsIgnoreCase(revstr.toLowerCase()))
//		{
//			System.out.println("its is palindrome");
//		}
//		else
//		{
//			System.out.println("it is not palindrome");
//		}
		for(int i=1;i<=n;i++)
		{
			System.out.println(i+"*"+i+"*"+i+"="+i*i*i);
		}
		
}
}