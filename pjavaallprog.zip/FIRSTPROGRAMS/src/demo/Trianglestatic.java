/* int area=(br*h)/2;
		int peri=a+b+c;

		*/
// 1.static method//
package demo;

public class Trianglestatic {
   static int br=4;
   static int h=3;
   static int a=2;
   static int b=3;
   static int c=4;
   
   public  static void area()
   {
	    int area=(br*h)/2;
	    System.out.println(area);
	   
   }
   public static void per()
   {
	   int per=a+b+c;
	   System.out.println(per);
   }
   public static void main(String[] args)
   {
	   area();
	   per();
   }
 
   
}
