package demo;

public class Rectangleinstance {
	// instance//
	
		int len ,br;
		double area, per;
		public void details(int l, int b)
		{
			len=l;
			br=b;
		}
		public void calculate()
		{
			area=len*br;
			per=2*(len+br);
		}
		public void display()
		{
		Rectangleinstance r= new Rectangleinstance();
		r.details(3, 2);
		r.calculate();
		r.display();
		}

	}



