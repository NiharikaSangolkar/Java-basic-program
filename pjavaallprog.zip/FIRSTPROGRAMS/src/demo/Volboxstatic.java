package demo;

public class Volboxstatic {
	static int L=3;
    static int B=4;
    static int H=5;
    public static void vol()
    {
    	 int vol=L*B*H;
    	 System.out.println(vol);
      }
    public static void main(String[]args)
    {
    	vol();
    }
    

}
