package demo;
//product and sum are = spy number
import java.util.Scanner;

public class Spynumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int  num=sc.nextInt();
		System.out.println();
		int pro=1,sum=0,ld;
		while(num>0)
		{
			ld=num%10;
			sum+=ld;
			pro*=ld;
			num=num/10;
			
			
		}
		if(sum==pro)
		{
			System.out.println("its spy");
		}
		else
		{
			System.out.println("its not spy");
		}
		
	}

}
