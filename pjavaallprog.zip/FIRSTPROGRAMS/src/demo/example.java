package demo;

import java.util.Scanner;

public class example {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int p=1,s=0;
		int ld;
		//temp=n;
		while(n>0)
		{
			ld=n%10;
			s+=ld;
			p*=ld;
			n=n/10;
		}
		if(s==p)
		{
			System.out.println("its spy");
		}
		else
		{
			System.out.println("not spy");
		}
		
	}

}
