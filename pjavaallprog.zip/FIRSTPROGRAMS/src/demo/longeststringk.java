package demo;

import java.util.HashSet;

public class longeststringk {
	// Java program to find the longest substring
	// with k unique characters in a given string
	
	// calculate length of
		// longest substring with k characters
		static void longestKSubstr(String s, int k)
		{

			int n = s.length();
			int answer = -1;
			for (int i = 0; i < n; i++) {
				for (int j = i + 1; j <= n; j++) {
					HashSet<Character> hs= new HashSet<Character>();
					for (int x = i; x < j; x++) {
						hs.add(s.charAt(x));
					}
					if (hs.size() == k) {
						answer = Math.max(answer, j - i);
					}
				}
			}

			System.out.println(answer);
		}

		public static void main(String[] args)
		{
			String s = "aabacbebebe";
			int k = 3;

			// Function Call
			longestKSubstr(s, k);
		}
	}

	



