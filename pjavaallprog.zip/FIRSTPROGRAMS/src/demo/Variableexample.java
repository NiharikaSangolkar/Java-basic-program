package demo;

public class Variableexample {
      
	
}
