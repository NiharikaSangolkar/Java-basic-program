/*static block
points to remember:
1)static block executed before the main method
2)we can write multiple static block*/
package demo;

public class Staticblock {
  static
  {
	  System.out.println("I am static block");
	  
  }
   /*static
   {
	   System.out.println("i am also static block ");
   }*/
  public static void main(String [] args)
  {
	  System.out.println("I am main method");
	  
  }
  static {
	  System.out.println("I am static block 2");
  }
}
