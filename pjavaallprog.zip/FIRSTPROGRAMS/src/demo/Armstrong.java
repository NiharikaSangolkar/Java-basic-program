package demo;

import java.util.Scanner;

public class Armstrong {
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number:");
		int n=sc.nextInt();
		System.out.println("enter number of digit:");
		int r=sc.nextInt();
		
		int p=0,temp;
	
		temp=n;
		while(n>0)
		{
			r=n%10;
			//p=(int(Math.pow(n, r));
			p=(int)((p)+(Math.pow(n,r)));
			n=n/10;
			
		}
		if(temp==p)
		{
			System.out.println("its armstrong number.");
		}
		else
		{
			System.out.println("not a armstrong number");
		}
	}

}
