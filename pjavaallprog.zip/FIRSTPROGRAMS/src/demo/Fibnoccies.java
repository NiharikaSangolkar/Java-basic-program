package demo;

import java.util.Scanner;

public class Fibnoccies {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter input");
		int n=sc.nextInt();
		int n1=0,n2=1,n3,counter=0;
		System.out.println("fibbonacies series are:");
		while(counter<n)
		{
			System.out.print(n1+"");
			n3=n1+n2;
			n1=n2;
			n2=n3;
			counter+=1;
		}
		


		
		
	}

}
