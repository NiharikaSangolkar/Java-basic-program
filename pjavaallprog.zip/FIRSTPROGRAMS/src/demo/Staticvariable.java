package demo;

public class Staticvariable {

	public  static void display() 
	{
	System.out.println("Display method");	
	}
	public static void add(int a, int b)
	{
		int c=a+b;
		System.out.println(c);
		
	}
	public static void main(String[] args)
	{
		display();
		add(23,12);
		
	}
}
