package demo;

public class rectanglestatic {
	static int l=4;
	static int b=5;
	public static void area()
	{
		int area=l*b;
		System.out.println(area);
	}
	public static void main(String[] args) {
		area();
	}

}
