package demo;

public class demo2 
{
 public static void main(String arr[])
 {
	 int a=5;
	 int b=2;
	 int c=a+b;
	 int d=a-b;
	 int e=a*b;
	 int f=a/b;
	 int g=a%b;
	 
 
 
 
 System.out.println(c);
 System.out.println(d);
 System.out.println(e);
 System.out.println(f);
 System.out.println(g);
 

 
}
}
