package demo;

public class Employee {
    double gross;
    static String company_name="puneri pattern";
    public void Emp_details(int eid,String name, String address,double salary)
    {
    	double da=0.10*salary;
    	double hra=0.15*salary;
    	gross =da+hra+salary;
    	System.out.println("Employee id is " +eid);
    	System.out.println("Employee name is " +name);
    	System.out.println("Employee address is " +address);
    	System.out.println("Employee salary is " +gross);
    	System.out.println("Employee company name is " +company_name);
    }
    public static void main(String[] args)
    {
    	//company_name="xyz.com";//
    	Employee em= new Employee();
    	em.Emp_details(1, "shatakshi", "pune",500);
    	company_name="xyz.com";
    	System.out.println();
    	em.Emp_details(2, "shalini", "delhi", 600);
    	
    			
    }
    
}
