package com.control;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class playermain {
	public static void main(String[] args) {
		System.out.println("player details...");
		Configuration cfg=new Configuration();
		cfg.configure("hibernateplayer.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		player p=new player();
		p.setPid(102);
		p.setPname("virat");
		p.setPcity("benglore");
		Session sn=sf.openSession();
		Transaction ts=sn.beginTransaction();
		sn.save(p);
		ts.commit();
		sn.close();
	}

}
