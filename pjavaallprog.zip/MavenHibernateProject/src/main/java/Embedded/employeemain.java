package Embedded;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class employeemain {
	public static void main(String[] args) {
		SessionFactory sf=new Configuration().configure("hibernateemp.cfg.xml").buildSessionFactory();
		Session sn=sf.openSession();
		Transaction t=sn.beginTransaction();
		Address a=new Address();
		a.setCid(101);
		a.setArea("jule solapur");
		a.setCity("solapur");
		
		Employee e=new Employee();
		e.setEid(404);
		e.setEname("birbal");
		e.setAddress(a);
		sn.save(e);
		t.commit();
	}

}
