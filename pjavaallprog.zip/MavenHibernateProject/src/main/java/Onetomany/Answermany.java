package Onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Answermany {
	@Id
	private int answerId;
	private String answers;
	@ManyToOne
	private QuestiontoOne question;
	public int getAnswerId() {
		return answerId;
	}
	public void setAnswerId(int answerId) {
		this.answerId = answerId;
	}
	public String getAnswers() {
		return answers;
	}
	public void setAnswers(String answers) {
		this.answers = answers;
	}
	public QuestiontoOne getQuestion() {
		return question;
	}
	public void setQuestion(QuestiontoOne question) {
		this.question = question;
	}
	

}
