package Onetomany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Mapdemo {
	public static void main(String[] args) {
		SessionFactory f=new Configuration().configure("hibernateonetomany.cfg.xml").buildSessionFactory();
		Session session=f.openSession();
		Transaction t=session.beginTransaction();
		QuestiontoOne q=new QuestiontoOne();
		q.setQuestionId(003);
		q.setQuestion("what are the four pillars of oops?");
		Answermany a1=new Answermany();
		a1.setAnswerId(123);
		a1.setAnswers("Polymorphism");
		a1.setQuestion(q);
		Answermany a2=new Answermany();
		a2.setAnswerId(124);
		a2.setAnswers("Encapsulation");
		a2.setQuestion(q);
		Answermany a3=new Answermany();
		a3.setAnswerId(125);
		a3.setAnswers("Inheritance");
		a3.setQuestion(q);
		Answermany a4=new Answermany();
		a4.setAnswerId(126);
		a4.setAnswers("Abstraction");
		a4.setQuestion(q);
		List<Answermany> list=new ArrayList<Answermany>();
		list.add(a1);
		list.add(a2);
		list.add(a3);
		list.add(a4);
		q.setAnswers(list);
		session.save(q);
		session.save(a1);
		session.save(a2);
		session.save(a3);
		session.save(a4);
		t.commit();
		
		
		
	}

}
