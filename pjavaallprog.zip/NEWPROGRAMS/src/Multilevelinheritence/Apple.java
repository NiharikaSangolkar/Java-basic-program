package Multilevelinheritence;

public class Apple extends Fruit {
	public  void apple()
	{
		System.out.println("enter number of apples");
		int a=sc.nextInt();
	    total_a=a;
	    System.out.println("total number of apples"+a);

		
		
	}

}

