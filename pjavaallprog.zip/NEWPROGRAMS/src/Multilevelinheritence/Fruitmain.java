package Multilevelinheritence;

public class Fruitmain {
	public static void main(String[] args) {
		Basket b=new Basket();
		b.fruit();
		b.apple();
		b.mango();
		b.basket();

}
}
