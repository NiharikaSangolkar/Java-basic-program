/*write class game {}
class board game extends game {}
class chess extends boardgame {}
*/
package Multilevelinheritence;

public class Team {
	public void teams()
	{
		System.out.println("Board games are");
	}

}
