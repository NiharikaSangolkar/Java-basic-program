/*1.Write a program to implement the following Multi Level Inheritance:
Class: Account
data members  : Cust_name , acc_no
                         
Class: Saving_Acc
data members  : Min_bal, saving_bal

Class:Acct_Details
data members  : Deposits, withdrawals

 */
package Multilevelinheritence;

public class Account {
	public void acc_details()
	{
		System.out.println("Account details are:");
		
		
	}

}
