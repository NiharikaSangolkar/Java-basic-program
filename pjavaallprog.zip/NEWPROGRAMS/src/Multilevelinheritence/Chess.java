package Multilevelinheritence;

public class Chess extends Board {
	public void chess_details(String game_name,int ps)
	{
		System.out.println("Board game:"+game_name);
		System.out.println("Player size:"+ps);
		
	}
	public static void main(String[] args) 
	{
		Chess c=new Chess();
		c.teams();
		c.board_details("Catan",4);
		c.chess_details("Chess", 2);
		
		
	}


}
