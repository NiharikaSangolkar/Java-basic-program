package Multilevelinheritence;

public class Mangoes extends Apple {
	public void mango() 
	{
		System.out.println("enter number of mangoes");
		int m=sc.nextInt();
		total_m=m;
		System.out.println("Total number of mangoes in basket:"+total_m);
		
		
		
	}

	

}
