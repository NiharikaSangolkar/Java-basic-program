package Multilevelinheritence;

public class Customer extends Account {
	public void account(String cust_name,int acc_no)
	{
		System.out.println("customer name"+cust_name);
		System.out.println("account number"+acc_no);
		
	}

}
