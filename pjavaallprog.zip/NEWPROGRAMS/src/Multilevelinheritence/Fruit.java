package Multilevelinheritence;

import java.util.Scanner;

public class Fruit {
	
    Scanner sc= new Scanner(System.in);
    int total_a;
    int total_m;
	public void fruit()
	{
		
	}

}
