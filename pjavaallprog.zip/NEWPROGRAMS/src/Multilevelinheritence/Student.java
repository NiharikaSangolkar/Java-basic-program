package Multilevelinheritence;

public class Student extends Teacher {
	public void student_details(String name,int m1,int m2)
	{
		System.out.println("student name is "+name);
		System.out.println("student marks "+(m1+m2));
	}
	public static void main(String[] args) {
		Student s=new Student();
		s.sc_details();
		s.teacher_details(" Riya ", 6);
		s.student_details(" xyz ", 56, 58);
		
	}

}
 