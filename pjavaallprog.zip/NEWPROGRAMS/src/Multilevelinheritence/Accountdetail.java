package Multilevelinheritence;

public class Accountdetail extends Saving {
	public void account_detail(double deposite,double withdraw)
	{
		System.out.println("deposite:"+deposite);
		System.out.println("withdraw"+withdraw);
	}
	public static void main(String[] args) 
	{
		Accountdetail a=new Accountdetail();
		a.acc_details();
		a.account("Ram kapoor", 45557780);
		a.sav_details(500, 5600000);
		a.account_detail(5000, 787770);
		
		
		
	}

}
