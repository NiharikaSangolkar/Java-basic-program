package Multilevelinheritence;

public class Teacher extends School {
	public void teacher_details(String name,int ex)
	{
		System.out.println("teacher name is "+name);
		System.out.println("teacher experience is "+ex+ "year");
		
	}

}
