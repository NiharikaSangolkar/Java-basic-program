package Multilevelinheritence;

public class Board extends Team {
	public void board_details(String game_name,int ps)
	{
		System.out.println("Board game:"+game_name);
		System.out.println("Player size: "+ps);
		
	}

}
