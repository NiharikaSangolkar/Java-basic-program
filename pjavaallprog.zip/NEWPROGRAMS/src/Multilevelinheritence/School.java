package Multilevelinheritence;

public class School {
	public void sc_details()
	{
		System.out.println("School name is xy");
	}

}
