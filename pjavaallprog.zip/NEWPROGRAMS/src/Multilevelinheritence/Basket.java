package Multilevelinheritence;

public class Basket extends Mangoes{
	public void basket()
	{
		int basket=total_m+total_a;
		System.out.println("Total number of fruits in basket are:"+basket);


	}
	
}
