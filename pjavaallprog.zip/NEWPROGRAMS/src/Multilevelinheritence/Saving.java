package Multilevelinheritence;

public class Saving extends Customer {
	public void sav_details(double min_bal,double saving_bal)
	{
		System.out.println("Min balance:"+min_bal);
		System.out.println("saving balance"+saving_bal);
		
	}

}
