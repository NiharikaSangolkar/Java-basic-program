package Overridingdemo;

public class Maininterest {
	public static void main(String[] args) {
		SBI s = new SBI(); 
		s.getInterest();
		s.getminbal();
		System.out.println();
	    PNB p= new PNB();
	    p.getInterest();
	    p.getminbal();
	}
}
