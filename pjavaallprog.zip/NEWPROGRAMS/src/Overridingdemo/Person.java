/*.Create a class 'Person' with a method 'readdetails' and 'showdetails'.
 *  It has two subclasses "Engineer and Doctor"each having a method with 
 *  the same name that reads and displays the details of data members .
 *   Call the methods by creating an object for each subclass.data members is :specialization
*/
package Overridingdemo;

//import java.util.Scanner;

public class Person {
     //Scanner sc= new Scanner(System.in);
	public void readdetails(String name, String Edu ,String c)
	{
	
		
	}
	public void showdetails(double salary)
	{
		
	}

}
