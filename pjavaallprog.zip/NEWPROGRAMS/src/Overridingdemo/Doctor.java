package Overridingdemo;

public class Doctor extends Person {
	@Override
	public void readdetails(String name, String Edu ,String c)
	{
		System.out.println("Name:"+name);
		System.out.println("Education:"+Edu);
		System.out.println("Job category:"+c);
	}
	@Override
	public void showdetails(double salary)
	{
		System.out.println("Salary of Doctor:"+salary);
		
	}
	

}
