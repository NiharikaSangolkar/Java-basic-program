package Overridingdemo;

public class MainA {
	public static void main(String[] args) {
		Animal a=new Animal();
		a.eat();
		a.drink();
		Dog d=new Dog();
		d.drink();
		d.eat();
		
	}

}
