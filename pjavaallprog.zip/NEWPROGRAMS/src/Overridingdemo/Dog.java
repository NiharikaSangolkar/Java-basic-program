package Overridingdemo;

public class Dog extends Animal {
	@Override
	public void eat()
	{
		System.out.println("Dog eats bone.");
	}

}
