package Overridingdemo;

public class Circlearea extends Shape {
	@Override
	public void area()
	{
		//int r=3;
		System.out.println("enter radius of circle");
		double r=sc.nextDouble();
		System.out.println("area of rectangle"+(3.14*r*r));
	}

}


