package Overridingdemo;

public class BankA extends Bank{
	@Override
	public void getBalance()
	{
		System.out.println("deposite in BankA:$100");
	}

}
