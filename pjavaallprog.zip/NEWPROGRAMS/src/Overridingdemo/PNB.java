package Overridingdemo;


public class PNB extends Interest{
	
	@Override
	public void getInterest()
	{
		System.out.println("Interest in PNB is 5.2%");
	}
	@Override
	public void getminbal()
	{
		System.out.println("minimum balance in PNB is 3000rs");
	}
}
