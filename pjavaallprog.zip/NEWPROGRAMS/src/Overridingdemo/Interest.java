package Overridingdemo;

public class Interest {
	
	public void getInterest()
	{
		System.out.println("Interest in bank is");
	}
	public void getminbal()
	{
		System.out.println("minimum balance is");
	}

}
