package Overridingdemo;

public class Parent {
	public void message()
	{
		System.out.println("this is the first class");
	}

}
