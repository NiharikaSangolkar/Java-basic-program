package Overridingdemo;

public class Cat extends Animal {
	@Override
	public void eat()
	{
		System.out.println("cat eats rat.");
	}
	@Override
	public void drink()
	{
		System.out.println("cat drink milk");
		
	}

}
