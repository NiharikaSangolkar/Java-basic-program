package Overridingdemo;

public class FullTimeStaff extends Staff {
	@Override
	public void staff_details(String s,double d)
	{
		System.out.println("department:"+s);
	
		System.out.println("salary:"+d);
		
		
	}
	

}
