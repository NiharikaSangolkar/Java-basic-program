package Overridingdemo;

public class BankC extends Bank{
	@Override
	public void getBalance()
	{
		System.out.println("deposite in BankC:$300");
	}

}
