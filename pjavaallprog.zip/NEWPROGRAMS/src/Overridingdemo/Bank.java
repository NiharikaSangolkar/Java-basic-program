package Overridingdemo;

public class Bank {
	public void getBalance()
	{
		System.out.println();
	}

}
