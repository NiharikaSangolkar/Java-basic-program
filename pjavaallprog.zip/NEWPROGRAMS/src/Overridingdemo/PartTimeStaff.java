package Overridingdemo;

public class PartTimeStaff extends Staff {
	@Override
	public void staff_details(String s,double p)
	{
		System.out.println("number of hours:"+s);
		
		System.out.println("rate per hours:"+p);
		
	}

}
