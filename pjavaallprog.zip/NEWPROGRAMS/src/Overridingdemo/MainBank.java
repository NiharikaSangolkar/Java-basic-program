package Overridingdemo;

public class MainBank {
	public static void main(String[] args) {
		BankA a=new BankA();
		a.getBalance();
		BankB b=new BankB();
		b.getBalance();
		BankC c=new BankC();
		c.getBalance();
		
		
	}

}
