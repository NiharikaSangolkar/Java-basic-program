package Overridingdemo;

public class Manager extends Company  {
	@Override
	public void memebr(String name,int age,long phonenumber,String address,double salary)
	{
		System.out.println("Name of the Manager:" +name);
		System.out.println("Age of the Manager:" +age);
		System.out.println("Phone number of Manager:" +phonenumber);
		System.out.println("address of Manager:" +address);
		System.out.println("salary of Manager:" +salary);
		
		
	}
	@Override
	public void speicalization(String s)
	{
		System.out.println("specialization:" +s);
	}
	@Override
	public void department(String d)
	{
		System.out.println("Department:" +d);
	}
	

}
