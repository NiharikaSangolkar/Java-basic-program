package Overridingdemo;

public class Mainpar {
	public static void main(String[] args) 
	{
		Subclass1 s=new Subclass1();
		s.message();
		System.out.println();
		Subclass2 n=new Subclass2();
		s.message();
		
		
		
	}

}
