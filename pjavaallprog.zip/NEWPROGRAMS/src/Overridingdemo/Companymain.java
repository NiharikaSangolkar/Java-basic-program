package Overridingdemo;

public class Companymain {
	public static void main(String[] args) 
	{
		Manager m=new Manager();
		m.memebr("Ram kapoor", 34, 943209999, "Mumbai", 500000);
		m.speicalization("MBA ");
		m.department(" TR Manager");
		System.out.println();
		Employee e=new Employee();
		e.memebr("Priya Sharma", 30, 560308050, "Pune", 455800);
		e.speicalization("B.Tech");
		e.department(" python developer");
		
	}

}
