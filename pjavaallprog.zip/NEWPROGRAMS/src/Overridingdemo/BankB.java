package Overridingdemo;

public class BankB extends Bank{
		@Override
		public void getBalance()
		{
			System.out.println("deposite in BankB:$200");
		}

	}


