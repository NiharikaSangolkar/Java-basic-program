package Overridingdemo;

public class Employee extends Company  {
	@Override
	public void memebr(String name,int age,long phonenumber,String address,double salary)
	{
		System.out.println("Name of the employee:" +name);
		System.out.println("Age of the employee:" +age);
		System.out.println("Phone number of employee:" +phonenumber);
		System.out.println("address of employee:" +address);
		System.out.println("salary of employee:" +salary);
		
		
	}
	@Override
	public void speicalization(String s)
	{
		System.out.println("specialization:" +s);
	}
	@Override
	public void department(String d)
	{
		System.out.println("Department:" +d);
	}
	

}