package Overridingdemo;

public class Animal {
	public void eat()
	{
		System.out.println("animals eats...");
	}
	public void drink()
	{
		System.out.println("Animals drink water");
	}

}
