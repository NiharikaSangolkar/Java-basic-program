package Hirarchical;

public class Fruitmain {
	public static void main(String[] args) {
		Apple a=new Apple();
		a.apple();
		a.fruit_detail("apple");
		Mangoes m=new Mangoes();
		m.mango();
		m.fruit_detail("mangoes");
	}

}
