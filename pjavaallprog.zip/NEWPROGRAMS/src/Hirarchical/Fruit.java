package Hirarchical;

import java.util.Scanner;

public class Fruit {
	int total;
    Scanner sc= new Scanner(System.in);
	public void fruit_detail(String a)
	{
		System.out.println("total no of fruit"+a+"is"+total);
	}
	

}
