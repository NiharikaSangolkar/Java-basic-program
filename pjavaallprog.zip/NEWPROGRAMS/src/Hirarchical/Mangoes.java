package Hirarchical;

public class Mangoes extends Fruit {
	public void mango() 
	{
		System.out.println("enter number of mangoes:");
		int m=sc.nextInt();
		total=m;
		
		
	}

}
