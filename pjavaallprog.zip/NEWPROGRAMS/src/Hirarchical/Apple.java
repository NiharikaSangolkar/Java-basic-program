package Hirarchical;

public class Apple extends Fruit {
	public void apple()
	{
		System.out.println("enter the number of apple");
		int a=sc.nextInt();
		total=a;
		
	}

}
