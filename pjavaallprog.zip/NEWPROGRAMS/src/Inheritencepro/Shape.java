//hirarchical
package Inheritencepro;

import java.util.Scanner;

public class Shape {
	public  void displayshape() 
	{
		System.out.println("This is a shape");
		
	}


}
