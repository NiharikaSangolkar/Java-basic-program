package Inheritencepro;

public class ParentH {
	public void messege()
	{
		System.out.println();
	}

}
