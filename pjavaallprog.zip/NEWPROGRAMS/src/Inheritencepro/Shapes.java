//hirarchical inheritences
package Inheritencepro;

import java.util.Scanner;

public class Shapes {
	 int area;
    Scanner sc= new Scanner(System.in);
	public void shape(String a)
	{
		System.out.println("area of"+a+"is"+area);
	}

}
