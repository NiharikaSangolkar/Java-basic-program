package Inheritencepro;

public class Bankmain {
	public static void main(String[] args) 
	{
		BankA a=new BankA();
		a.getBalance();
		a.bankA_details(100);
		BankB b=new BankB();
	
		b.bankB_details(150);
		BankC c=new BankC();
		//c.getBalance();
		c.bankc_details(200);
		
	}

}
