//hirarchical
package Inheritencepro;

public class Racecar extends Automobile
{
	public void race_car(String n,String p,double pr)
	{
		System.out.println("car  name is:" +n);
		System.out.println("car colour is: " +p);
		System.out.println("car price :" +pr+ "crore");
		
	}
	public static void main(String[] args)
	{
		Racecar r=new Racecar();
		r.auto_mobile("4-wheeler");
		r.race_car("BMW", "Black", 1);
		
	}

}
