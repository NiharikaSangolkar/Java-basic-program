//hirarchical inheritence
package Inheritencepro;

public class Shrectangle extends Shapes {
	public void rect_area()
	{
		System.out.println("enter height and base");
		int h=sc.nextInt();
		int b=sc.nextInt();
		area=b*h;
		//System.out.println("area of rectangle:"+area);
		
		
	}
	

}
