package Inheritencepro;

public class Manager extends Employee{
	private  double b;
	//double total;
	public void man_detail(double bonus)
	{
		b=bonus;
		double total=salary+bonus;
		System.out.println("total salary"+total);
	}
	public static void main(String[] args)
	{
		Manager m=new Manager();
		//m.display();
		m.accept(101, "raj", "TR", 500000);
		m.man_detail(50);
		m.display();
		//m.mdisplay();
		
	}

}
