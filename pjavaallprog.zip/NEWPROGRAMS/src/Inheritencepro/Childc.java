package Inheritencepro;

public class Childc extends Parentc {
	public  void child_details()
	{
		System.out.println("This  is chilld class");
	}
	public static void main(String[] args)
	{
		Childc c=new Childc();
		c.par_detail();
		c.child_details();
		
	}
	
	

}
