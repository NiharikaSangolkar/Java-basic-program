package Inheritencepro;

public class BankC extends Bank {
	public void bankc_details(double d)
	{
		System.out.println("deposite of bank c:"+d+"$");
		
	}


}
