//hirarchical
package Inheritencepro;

public class Rectangle extends Shape 
{
	public void rec_details ()
	{
		System.out.println("This is rectangle class");
	}

}
