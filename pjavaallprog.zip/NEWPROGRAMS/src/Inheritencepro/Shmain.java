package Inheritencepro;

public class Shmain {
	public static void main(String[] args) 
	{
		Shrectangle p=new Shrectangle();
		p.rect_area();
		p.shape("rectangle:");
		Shsquare w=new Shsquare();
		w.squ_area();
		w.shape("square");
		
	}

}
