/*.Create an class 'Bank' with a method 'getBalance'. 
  $100, $150 and $200 are deposited in banks A, B and C respectively. 
  'BankA', 'BankB' and 'BankC' are subclasses of class 'Bank', each having a method named 
 'getBalance'. Call this method by creating an object of each of the three classes.
*/
package Inheritencepro;

public class Bank {
	public void getBalance()
	{
		System.out.println();
	}
	

}
