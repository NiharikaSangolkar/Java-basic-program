package Inheritencepro;

public class BankA extends Bank{
	public void bankA_details(double d)
	{
		System.out.println("deposite of bank A:"+d+"$");
		
	}

}
