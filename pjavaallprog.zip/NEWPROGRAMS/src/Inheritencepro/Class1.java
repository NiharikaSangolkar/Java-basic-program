package Inheritencepro;

public class Class1 extends ParentH {
	public void class1_detail()
	{
		System.out.println("This is class 1");
	}

}
