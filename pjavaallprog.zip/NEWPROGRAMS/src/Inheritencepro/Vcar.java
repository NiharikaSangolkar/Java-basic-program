//single inheritence
package Inheritencepro;

public class Vcar extends Vehicle
{
	public void vcar(String c,String n) 
	{
		System.out.println("colour of car :"+c);
		System.out.println("Name of car:"+n);
		
	}
	public static void main(String[] args)
	{
		Vcar v=new Vcar();
		v.vehi("4 wheeler");
		v.vcar("Black-light blue", "BMW");
		
	}
	

}
