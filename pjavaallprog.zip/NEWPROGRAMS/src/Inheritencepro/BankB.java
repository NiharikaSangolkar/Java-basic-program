package Inheritencepro;

public class BankB extends Bank {
	public void bankB_details(double d)
	{
		System.out.println("deposite of bank B:"+d+"$");
		
	}


}
