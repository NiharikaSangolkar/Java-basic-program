/*Define a class Employee having public members–id,name,department,
salary. total salary=salary+bonus
Define appropriate methods.
Create a subclass called “Manager” with private member bonus.
Define methods accept and display in both the classes.
*/
package Inheritencepro;

public class Employee {
	
	int id;
	String name;
	String department;
	double salary;
	double bonus;
	
	public void accept(int eid,String ename,String edept,double esalary)
	{
		id=eid;
		name=ename;
		department=edept;
		salary=esalary;
		
		
		
	}
	public void display()
	{
		System.out.println("employee id:"+id);
		System.out.println("employee name:"+name);
		System.out.println("employee department:"+department);
		System.out.println("employee salary:"+salary);
		//System.out.println("total salary:"+(salary+bonus));
		
		
	}

}
