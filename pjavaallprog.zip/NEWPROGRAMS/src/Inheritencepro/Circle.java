//hirarchicle ex:1
package Inheritencepro;

public class Circle extends Shape
{
	public void circle_detail()
	{
		System.out.println("This is circle class");
	}

}
