package Inheritencepro;

public class Shsquare extends Shapes {
	public void squ_area()
	{
		System.out.println(" Enter side of square:");
		int a=sc.nextInt();
		area=a*a;
		//System.out.println("area of square:"+area);
	}

}
