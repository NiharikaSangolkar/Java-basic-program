package Inheritencepro;

public class Parentmain {
	public static void main(String[] args) 
	{
		Class1 c=new Class1();
		//c.getClass();
		c.messege();
		c.class1_detail();
		Class2 b=new Class2();
		b.Class2_details();
		
	}

}
