//single inheritence
package Inheritencepro;

public class Vehicle {
	public void vehi(String n)
	{
		System.out.println("vehicle type is:" +n);
		
	}

}
