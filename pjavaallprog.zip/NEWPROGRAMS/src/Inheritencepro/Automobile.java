/* 1.create Parent class Automobile
create a subclass of Automobile called  RaceCar.
Create appropirate methods to intialize and
display the value of datamembers(take datamembers of your choice)
*/
package Inheritencepro;

public class Automobile {
	public void auto_mobile(String s)
	{
	System.out.println("Type Of Automobile:"+s);
	
	}
	

}
