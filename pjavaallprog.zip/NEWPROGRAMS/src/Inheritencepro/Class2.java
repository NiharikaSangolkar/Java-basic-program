package Inheritencepro;

public class Class2 extends ParentH {
	public void Class2_details()
	{
		System.out.println("This is class 2");
	}

}
