package Inheritencepro;

public class Parentc{
	
	public void par_detail()
	{
		System.out.println("This is parent class");
	}

}
