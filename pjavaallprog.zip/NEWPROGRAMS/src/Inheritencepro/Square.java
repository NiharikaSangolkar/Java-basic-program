//hirarchical

package Inheritencepro;

public class Square extends Rectangle
{
	public void square_detail()
	{
		System.out.println("Square is rectangle");
	}

}
