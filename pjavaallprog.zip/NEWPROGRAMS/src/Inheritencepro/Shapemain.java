//hirarchical
package Inheritencepro;

public class Shapemain {
	public static void main(String[] args) 
	{
		Circle c=new Circle();
		c.displayshape();
		c.circle_detail();
		Rectangle r=new Rectangle();
		r.rec_details();
		Square s=new Square();
		s.square_detail();
	
	}

}
