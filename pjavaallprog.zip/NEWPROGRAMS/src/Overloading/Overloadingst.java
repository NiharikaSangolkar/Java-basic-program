package Overloading;

public class Overloadingst {
	public static void main(String[] args) {
		main(4.5);
		main(5);
		
		
		System.out.println("string arg method");
	}
	public  static void main(int a) {
		System.out.println("int method");
		
	}
	public static void main(double c) {
		System.out.println("double methods");
		
	}
	

}
