package Overloading;

public class Area {
	public void area(int a)
	{
		System.out.println("area of square:" +(a*a));
	}
	public void area(int l,int b)
	{
		System.out.println("area of rectangle:" +(l*b));
	}
	public static void main(String[] args) 
	{ 
		Area a=new Area();
		a.area(4);
		a.area(4, 5);
		
	}

}
