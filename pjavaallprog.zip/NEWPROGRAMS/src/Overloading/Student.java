/*Create a class 'Student' with three data members which are name, age and address.  
 * it has three functions with the same name 'setInfo'.  
 * The first method with no argument assigns default values to name as "unknown", 
 * age as '0' and address as "not available". 
 * second method has two parameters for name and age and 
 * assigns the same whereas the third method  has three
 * parameters which are assigned to name, age and address respectively. 
 * Print the name, age and address of student.
*/
package Overloading;

public class Student {
	public void Set_info()
	{
		System.out.println("Name of student:unknown");
		System.out.println("Age of student:0");
		System.out.println("Address of student:Not available");
	}
	public void set_info(String name,int age,String add)
	{
		System.out.println("Name of student:"+name);
		System.out.println("Age of student:"+age);
		System.out.println("Address of student:"+add);
		
	}
	public static void main(String[]args)
	{
		Student s=new Student();
		s.Set_info();
		s.set_info("Ram Kapoor", 20, "Mumbai");
		
	}

}
