/*B.Create a class named 'Programming'. While creating a method of the class, if nothing is passed to it, then the message "I love programming languages" should be printed. If some String is passed to it, then in place of "programming languages" the name of that String variable should be printed.
For example, while creating the object if we pass "cpp", then "I love cpp" should be printed.
*/
package Overloading;

public class Programming {
	public void program()
	{
		System.out.println("I love programming languages ");
	}
	public void program(String c)
	{
		System.out.println("I love " +c);
		
	}
	public static void main(String[] args) 
	{
		Programming p=new Programming();
		p.program();
		p.program("cpp");
		
	}

}
