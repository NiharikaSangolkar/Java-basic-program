package Overloading;

public class Addition {
	public  static void add(int a,int b)
	{
		System.out.println("addition of "+a+"+" +b+"="+(a+b));
		
	}
	public static void main(String[] args) {
		//Addition a=new Addition();
		add(4, 5);
	}
	

}
