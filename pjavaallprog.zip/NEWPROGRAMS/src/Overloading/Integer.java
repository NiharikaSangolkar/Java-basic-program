/*Create a class to print an integer and a character using two functions having the same name
  but different sequence of the integer and the character parameters.
For example, if the parameters of the first function are of the form (int n, char c), 
then that of the second function will be of the form (char c, int n).
*/
package Overloading;

public class Integer {
	public void integer_detail(int n,char c)
	{
		System.out.println("Number is:"+n);
		System.out.println("Grade is:"+c);
		
	}
	public void integer_detail(char c, int n)
	{
		System.out.println("Grade is:"+c);
		System.out.println("Number is:"+n);
		
	}
	public static void main(String[] args) 
	{
		Integer i=new Integer();
		i.integer_detail(1, 'A');
		i.integer_detail('B', 2);
		
	}
	

}
