/*Create a class named 'Rectangle' with two data members- length and breadth and a function to calculate the area which is 'length*breadth'. The class has three methods which are :
1 - having no parameter - values of both length and breadth are assigned zero.
2 - having two numbers as parameters - the two numbers are assigned as length and breadth respectively.
3 - having one number as parameter - both length and breadth are assigned that number.
Now, create objects of the 'Rectangle' class call the methods  and print their areas.*/
package Overloading;

public class Rectangle {
	public void rectangle()
	{
		int l=0;
		int b=0;
		System.out.println("area="+(l*b));
	}
	public void rectangle(int l,int b)
	{
		System.out.println("area="+(l*b));
	}
    public void rectangle(int l)
	{
    	int b=4;
    	System.out.println("area="+(l*b));
		
	}
    public static void main(String[]args)
    {
    	Rectangle r=new Rectangle();
    	r.rectangle();
    	r.rectangle(5, 4);
    	r.rectangle(4);
    }
	

}
