package com.basicex;

public class caluclation {
	public  int Square(int a)
	{
		return a*a;
	}

}
