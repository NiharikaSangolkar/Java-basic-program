package crud;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class UserDao {
	public static Connection getConnection()
	{
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		    con = DriverManager.getConnection("jdbc:mysql://localhost/dbtest", "root", "Niharika2001");
		
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		return con;
	}
	public static int save(Userbean u)
	{
		int status=0;
		try {
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("insert into register(name,city,email,password) values(?,?,?,?)");
			ps.setString(1, u.getName());
			ps.setString(2, u.getCity());
			ps.setString(3, u.getEmail());
			ps.setString(4, u.getPassword());
			status=ps.executeUpdate();
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		return status;
	}
	public static int update(Userbean u)
	{
		int status=0;
		try {
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("update register set name=?, city=?,email=?,password=? where id=?");
			ps.setString(1, u.getName());
			ps.setString(2, u.getCity());
			ps.setString(3, u.getEmail());
			ps.setString(4, u.getPassword());
			ps.setInt(5,u.getId());
			status=ps.executeUpdate();
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		return status;
	}
	
	public static int delete(Userbean u)
	{
		int status=0;
		try {
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("delete from register where id=?");
			
			ps.setInt(1,u.getId());
			status=ps.executeUpdate();
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		return status;
	}
	public static List<Userbean> getAllRecords()
	{
		List<Userbean> list= new ArrayList<Userbean>();
		try {
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("select * from register");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Userbean u=new Userbean();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setCity(rs.getString("city"));
				u.setEmail(rs.getString("email"));
				u.setPassword(rs.getString("password"));
				list.add(u);
				
			}
			
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		return list;
		
	}
	public static Userbean getRecordById(int id)
	{
		Userbean u=null;
		try {
			Connection con=getConnection();
			PreparedStatement ps=con.prepareStatement("select * from register where id=?");
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				u=new Userbean();
				
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setCity(rs.getString("city"));
				u.setEmail(rs.getString("email"));
				u.setPassword(rs.getString("password"));
				
				
			}
			
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		return u;
	
	}

	
}
