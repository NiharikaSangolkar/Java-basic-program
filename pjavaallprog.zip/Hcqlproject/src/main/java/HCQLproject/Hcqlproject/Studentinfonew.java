package HCQLproject.Hcqlproject;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Studentinfonew {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private int id;
		private String name;
		private String city;
		private String course;
		private String duration;
		private int marks;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public String getDuration() {
			return duration;
		}
		public void setDuration(String duration) {
			this.duration = duration;
		}
		public int getMarks() {
			return marks;
		}
		public void setMarks(int marks) {
			this.marks = marks;
		}
		@Override
		public String toString() {
			return "Studentinfo [id=" + id + ", name=" + name + ", city=" + city + ", course=" + course + ", duration="
					+ duration + ", marks=" + marks + "]";
		}
		

	}


