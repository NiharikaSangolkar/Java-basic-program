package HCQLproject.Hcqlproject;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
	public static void main(String[] args) {
		SessionFactory f = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session session = f.openSession();
		Transaction ts = session.beginTransaction();
      // Studentinfonew si = new Studentinfonew();
//		si.setId(125);
//		si.setName("riya");
//		si.setCity("pune");
//		si.setCourse("python");
//		si.setDuration("5month");
//		si.setMarks(87);
//		session.save(si);
//		ts.commit();
          Criteria c=session.createCriteria(Studentinfonew.class);
         // c.setFirstResult(1);
          c.setMaxResults(3);
           List<Studentinfonew>l=c.list();
           Iterator it=l.iterator();
          while(it.hasNext())
        {
       	Studentinfonew s1=(Studentinfonew) it.next();
      	System.out.println(s1.getId());
        	System.out.println(s1.getName());
        	System.out.println(s1.getCity());
        	System.out.println(s1.getCourse());
        	System.out.println(s1.getDuration());
        	System.out.println(s1.getMarks());
        	
       }
	}
}
