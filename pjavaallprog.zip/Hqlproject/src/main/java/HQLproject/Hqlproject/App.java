package HQLproject.Hqlproject;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

//import com.mysql.cj.Query;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       SessionFactory f=new Configuration().configure().buildSessionFactory();
       Session session=f.openSession();
       Transaction t=session.beginTransaction();
       student s=new student();
//       s.setName("riya");
//       s.setCity("mumbai");
//       s.setCourse("Android");
//       s.setMarks(89);
//       session.save(s);
//       t.commit();
//      Query q=session.createQuery("from student");
//      List<student>list=q.list();
//      for(student s1:list)
//      {
//    	  System.out.println(s1);
//      }
       // delete hal query
//       String query="delete from student where id=:id";
//       Query q=session.createQuery(query);
//       q.setParameter("id", 1);
//       int r=q.executeUpdate();
//       System.out.println(r+"record deleted");
//       t.commit();
//       Query q=session.createQuery("update student set name=:n where id=:id");
//       q.setParameter("n", "ram");
//       q.setParameter("id", 2);
//       int r=q.executeUpdate();
//       System.out.println(r+"object updated");
//       t.commit();
//       
       //aggregate function
       //getting total
//       Query q=session.createQuery("select sum(marks)from student");
//       List<Integer>list=q.list();
//       System.out.println(list.get(0));
       //getting maximum marks
//       Query q=session.createQuery("select max(marks)from student");
//       List<Integer>list=q.list();
//       System.out.println(list.get(0));
       //getting min marks
//       Query q=session.createQuery("select min(marks)from student");
//       List<Integer>list=q.list();
//       System.out.println(list.get(0));
//       //count total no student id
//       Query q=session.createQuery("select count(id)from student");
//       List<Integer>list=q.list();
//       System.out.println(list.get(0));
       //avg of marks
       Query q=session.createQuery("select avg(marks)from student");
       List<Integer>list=q.list();
       System.out.println(list.get(0));
    }
}
