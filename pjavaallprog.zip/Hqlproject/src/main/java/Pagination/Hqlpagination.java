package Pagination;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;



public class Hqlpagination {
	public static void main(String[] args) {
		SessionFactory sf=new Configuration().configure().buildSessionFactory();
		Session session=sf.openSession();
		Transaction ts=session.beginTransaction();
		Query query=session.createQuery("from Studentinfo");
		//implementing pagination using hibernate
		query.setFirstResult(1);
		//query.setMaxResults(3);
		List<Studentinfo>list=query.list();
		for(Studentinfo st:list)
		{
			System.out.println(st.getId()+":"+st.getName()+":"+st.getCourse());
		}
		
		
		
	}

}
