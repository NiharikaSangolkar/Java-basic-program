/**
 * 
 */
/**
 * 
 */
module JDBCProject {
	requires java.sql;
}