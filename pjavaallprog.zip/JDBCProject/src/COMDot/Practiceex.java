package COMDot;
import java.sql.*;

public class Practiceex {
	public static void getdata()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/farmer", "root", "Niharika2001");
			String sql="select *from farmer_detail";
			Statement st=con.createStatement();
			ResultSet rt=st.executeQuery(sql);
			while(rt.next())
			{
				System.out.println("id:"+rt.getInt(1)+" name:"+rt.getString(2)+"date:"+rt.getDate(3)+"CROP_YEILD"+rt.getString(4)+"gender"+rt.getString(5));
			}
			} catch (ClassNotFoundException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void insertdata()
	{
		try { 
			int result=0;
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/farmer","root","Niharika2001");
			Statement st=con.createStatement();
			String sql="insert farmer_detail values(302,'dhg','2001-12-12','no','f')";
			result=st.executeUpdate(sql);
			if(result>0)
			{
				System.out.println("inserted successfully.");
			}
			
			
			
		} catch (ClassNotFoundException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/*
	public static void deletedata()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/examplesql", "root", "Niharika2001");
			
		} catch (ClassNotFoundException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	*/
	public static void main(String[] args) {
		Practiceex p=new Practiceex();
		p.getdata();
		p.insertdata();
		
	}

}
