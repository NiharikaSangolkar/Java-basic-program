package COMDot;

import java.sql.*;
public class connnectionprovider {
	public static Connection getConnection()
	{
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
             //con=DriverManager.getConnection("");
 			con=DriverManager.getConnection("jdbc:mysql://localhost/dbtest","root","Niharika2001");

			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return con;
		
	}

}
