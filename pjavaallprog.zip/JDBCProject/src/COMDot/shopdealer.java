package COMDot;

import java.sql.*;

public class shopdealer {
	private static final String url="jdbc:mysql://localhost/examplesql";
	private static final String root="root";
	private static final String password="Niharika2001";
	
	public static void getdata()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c=DriverManager.getConnection(url,root,password);
			Statement st=c.createStatement();
			String sql="select *from shop";
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				System.out.println("article:"+rs.getInt(1)+" dealer:"+rs.getString(2)+" price:"+rs.getDouble(3));
			}
			c.close();
			
			
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
			
			//e.printStackTrace();
		}
	}
	public static void insertdata() throws ClassNotFoundException
	{
		try {
			int result=0;
			Connection c=DriverManager.getConnection(url, root, password);
			Statement st=c.createStatement();
			String sql="insert into shop values(105,'MNO',20.5)";
			result=st.executeUpdate(sql);
			if(result>0)
			{
				System.out.println("data inserted succesfully!");
			}
			else
			{
				System.out.println("data insertion failed");
			}
		}
			
		 catch (SQLException e) {
			e.printStackTrace();
		
		 }	
	}
	public static void updateData()
	{
		try {
			int result=0;
             Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection c=DriverManager.getConnection(url, root, password);
			String sql="update shop set dealer='RST',price=45.6 where article=103";
			Statement st= (Statement)c.createStatement();
			result=st.executeUpdate(sql);
			if(result>0)
			{
				System.out.println(" data updated successfully");
			}
			else
			{
				System.out.println(" data updated got failed");
			}

			
		} 
		 catch (SQLException |ClassNotFoundException e) {
				e.printStackTrace();
				// TODO: handle exception
			}

	}
	public static void deleteData()
	{
		try {
			int result=0;
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection c=DriverManager.getConnection(url, root, password);
			String sql="delete from shop where price=12.6";
			Statement st= (Statement)c.createStatement();
			result=st.executeUpdate(sql);
			if(result>0)
			{
				System.out.println("deleted successfully");
			}
			
			else
			{
				System.out.println("deleted got failed");
			}

			
		} catch (SQLException |ClassNotFoundException e) {
			e.printStackTrace();
			// TODO: handle exception
			
		}
	}
		
	
	
	
	
	public static void main(String[] args) throws ClassNotFoundException {
		getdata();
		insertdata();
		updateData();
		deleteData();
		
		
	}

}
