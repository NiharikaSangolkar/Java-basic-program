package COMDot;
import java.sql.*;

public class AddData {
	public static void addData()
	{
		try {
			int result=0;
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/dbtest","root","Niharika2001");
			String sql="insert into person(personname,contactdetails,address)values('riya','23455555','pune')";
			Statement st= (Statement)c.createStatement();
			result=st.executeUpdate(sql);
			if(result>0)
			{
				System.out.println("insertion updated successfully");
			}
			else
			{
				System.out.println("insertion failed");
			}

			
		} catch (SQLException |ClassNotFoundException e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	public static void updateData()
	{
		try {
			int result=0;
             Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/dbtest","root","Niharika2001");
			String sql="update person set personname='wxy',contactdetails='34556643233'where personid=2";
			Statement st= (Statement)c.createStatement();
			result=st.executeUpdate(sql);
			if(result>0)
			{
				System.out.println("updated successfully");
			}
			else
			{
				System.out.println("updated got failed");
			}

			
		} 
		 catch (SQLException |ClassNotFoundException e) {
				e.printStackTrace();
				// TODO: handle exception
			}

	}
	public static void deleteData()
	{
		try {
			int result=0;
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/dbtest","root","Niharika2001");
			String sql="delete from person where personname='riya'";
			Statement st= (Statement)c.createStatement();
			result=st.executeUpdate(sql);
			if(result>0)
            {
				System.out.println("deleted successfully");
			}
			else
			{
				System.out.println("deleted got failed");
			}

			
		} catch (SQLException |ClassNotFoundException e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
		
	
	
	
	
	public static void main(String[] args) {
		addData();
		updateData();
		deleteData();
		
		
	}
	

}
