package COMDot;
import java.sql.*;

public class Employeejdbc {
	public static void data()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Connection c=DriverManager.getConnection("jdbc:mysql://localhost/dbtest","root","Niharika2001");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost/examplesql","root","Niharika2001");
			Statement st=c.createStatement();
			String sql="select *from employee";
			ResultSet rt=st.executeQuery(sql);
			while(rt.next())
			{
				System.out.println("ID: "+rt.getInt(1)+" AGE: "+rt.getInt(2)+" FIRST NAME:  " +rt.getString(3)+" Last Name:"+rt.getString(4));
			}

		} catch (ClassNotFoundException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		data();
	}

}
