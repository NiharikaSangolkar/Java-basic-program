package COMDot;
import java.sql.*;
import java.sql.DriverManager;

public class Student {
	public static void insertdata()
	{
		try { int result=0;
			Class.forName("com.mysql.cj.jdbc.Driver");
		    Connection con=DriverManager.getConnection("jdbc:mysql://localhost/employee", "root", "Niharika2001");
		    Statement st=con.createStatement();
		    String s="insert into student(st_id,st_name,st_marks)values(2,'priya kappor',96)";
		    result=st.executeUpdate(s);
		    if(result>0)
		    {
		    	System.out.println("inserted successfully");
		    }
		    else
		    {
		    	System.out.println("insertion got failed");
		    }
		    
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void selectdata()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/employee","root","Niharika2001");
			Statement st=con.createStatement();
			String sql="select *from student";
			ResultSet rt=st.executeQuery(sql);
			while(rt.next())
			{
				System.out.println("student_id: "+rt.getInt(1)+" student_name: "+rt.getString(2)+" student_marks: "+rt.getInt(3));
			}
		} catch (ClassNotFoundException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void updatedata()
	{
		try {
			int result=0;
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/employee","root","password");
			Statement st=con.createStatement();
			String sql="update student set st_marks=98 where st_id=1";
			result =st.executeUpdate(sql);
			if(result>0)
			{
				System.out.println("updated successfully");
				
			}
			else {
				System.out.println("updation got failed");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		insertdata();
		selectdata();
		updatedata();
		
	}

}
