package COMDot;
import java.sql.*;

public class Prepairedstatement {
	Connection con =connnectionprovider.getConnection();
	public void insertData() throws SQLException
	{
		int result=0;
		String sql="insert into person(personname,contactdetails,address) values(?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, "EjJOTY");
		ps.setString(2, "935965858");
		ps.setString(3, "dubai");
		result=ps.executeUpdate();
		if(result>0)
		{
			System.out.println("inserted successfully");
			
		}
		else {
			System.out.println("insertion failed");
		}
		
	}
	public  void getdata() throws SQLException
	{
		String sql="select * from person where personid = ?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, 1);
			ResultSet rs=ps.executeQuery();
		while(rs.next())
			{
				System.out.println(rs.getInt(1)+""+rs.getString(2)+""+rs.getInt(3));
			}
		
} 	
	void update()throws SQLException{
		int value=0;
		String sql="update person set contactdetails=?,address=? where personid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, "4876873759");
		ps.setString(2, " new delhi");
		ps.setInt(3, 1);
		value=ps.executeUpdate();
		if(value>0)
		{
			System.out.println("successfully updated");
		}
		
		
	}
	public void delete()throws SQLException{
		int value=0;
		String sql="delete from person where personid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		
		ps.setInt(1, 1);
		value=ps.executeUpdate();
		if(value>0)
		{
			System.out.println("successfully deleted");
		}
		
		
	}
		
public static void main(String[] args) throws SQLException {
		Prepairedstatement p=new  Prepairedstatement();
		//p.insertData();
		p.getdata();
		p.update();
		p.delete();
		
	}
	

}
