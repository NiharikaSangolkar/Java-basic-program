package COMDot;
import java.sql.*;
public class Check {
	    String url="jdbc:mysql://localhost/examplesql";
		String root="root";
		String password="Niharika2001";
		public void getdata()
		{
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection c=DriverManager.getConnection(url, root, password);
				Statement st=c.createStatement();	
				String sql="SELECT salesman_id,name,city,commission FROM Salesman;";
				ResultSet rt=st.executeQuery(sql);
				while(rt.next())
				{
					System.out.println("salesman_id: "+rt.getInt(1)+" name: "+rt.getString(2)+" city: "+rt.getString(3)+" commission:"+rt.getDouble(4));
					
				}
			} catch (ClassNotFoundException |SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		public  void insert()throws ClassNotFoundException
		
		{
			try {
				int rt=0;
				Connection c=DriverManager.getConnection(url, root, password);
				String s="insert into Salesman(salesman_id,name,city,commission)values(5015,'riya sharma','rome',0.85)";
				Statement st=(Statement)c.createStatement();
		        rt=st.executeUpdate(s);
				if(rt>0)
				{
					System.out.println("inserted successfully.");
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
		}
		public void delete()throws ClassNotFoundException {
			try {
				int rt=0;
				Connection c=DriverManager.getConnection(url, root, password);
				String s="delete from Salesman where salesman_id=5002";
				Statement st=(Statement)c.createStatement();
		        rt=st.executeUpdate(s);
				if(rt>0)
				{
					System.out.println("deleted successfully.");
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
		}

		public static void main(String[] args)throws ClassNotFoundException {
			Check s=new Check();
			s.getdata();
			s.insert();
			s.delete();
		}

	}



