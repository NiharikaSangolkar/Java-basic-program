package COMDot;
import java.sql.*;

public class TableData {
	public void readData() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/dbtest","root","Niharika2001");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select *from employee");
		/*while(rs.next())
		{
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
			System.out.println();
		}*/
		//metadata:provides methods to get meta data of a database such as name,id,version
		ResultSetMetaData rmd=rs.getMetaData();
		System.out.println("total column:"+rmd.getColumnCount());
		System.out.println("column name:"+rmd.getColumnName(2));
		System.out.println("column types name of 1st column:"+rmd.getColumnTypeName(1));
		System.out.println("table name:"+rmd.getTableName(1));
		}
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		TableData td=new TableData();
		td.readData();
	}

}
