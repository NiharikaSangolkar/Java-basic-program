package COMDot;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class practicedata {
	public static void select()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/examplesql","root","Niharika2001");
			String sql="select *from salesman";
			Statement st=con.createStatement();
			ResultSet rt=st.executeQuery(sql);
			while(rt.next()) {
				System.out.println("id "+rt.getInt(1)+" name "+rt.getString(2)+"city"+rt.getString(3)+" price "+rt.getDouble(4));
				
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		select();
	}

}
