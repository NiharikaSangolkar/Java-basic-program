package register;
import java.sql.*;

import java.util.Scanner;
public class RegisterUser {
	Scanner sc=new Scanner(System.in);
	Connection con=Connectionprovider.getConnection();
	public void adduser()
	{
		UserInfo u=new UserInfo();
		System.out.println("Enter user Data");
		u.setName(sc.nextLine());
		u.setMobile(sc.nextLine());
		u.setEmail(sc.nextLine());
		String sql="insert into userdata(name,mobile,email)values(?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, u.getName());
			ps.setString(2, u.getMobile());
			ps.setString(3, u.getEmail());
			
			int status=ps.executeUpdate();
			if(status>0)
			{
				System.out.println("insertion successfully");
			}
			else
			{
				System.out.println("insertion got failed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void showuser()
	{
		try {
			PreparedStatement ps=con.prepareStatement("select *from userdata");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				System.out.println("user id:"+rs.getInt(1));
				System.out.println("Name:"+rs.getString(2));
				System.out.println("Mobile:"+rs.getString(3));
				System.out.println("Email:"+rs.getString(4));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void searchuser()
	{
		System.out.println("Enter user id which you want to search");
		int id=sc.nextInt();
		String sql="select *from userdata where uid=? ";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				System.out.println("user id:"+rs.getInt(1));
				System.out.println("Name:"+rs.getString(2));
				System.out.println("Mobile:"+rs.getString(3));
				System.out.println("Email:"+rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void updatedata()
	{  
	   
	    System.out.println("enter userid which you want to update");
	    int id=sc.nextInt();
	    
	    System.out.println("Enter name:");
	    String s=sc.next();
	    //u.setName(sc.nextLine());
		
   try {
	   String sql="update userdata set name=? where uid=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, s);
		ps.setInt(2,id);
		
		int status=ps.executeUpdate();
		if(status>0)
		{
			System.out.println("updated successfully");
		}
		else
		{
			System.out.println("updation got failed");
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
		
		
	
	
	public void deleteData()
	{
		System.out.println("enter data which you want to delete:");
		int id=sc.nextInt();
		
		try {
			PreparedStatement p=con.prepareStatement("delete from userdata where uid=?");
			p.setInt(1, id);
			int status=p.executeUpdate();
			if(status>0)
			{
				System.out.println("record deleted successfully");
			}
			else
			{
				System.out.println("deletion failed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void addressdata()
	{
		
		System.out.println("Enter address Details:");
		Address a=new Address();
		a.setCity(sc.nextLine());
		a.setLocation(sc.nextLine());
		a.setPin(sc.nextInt());
		System.out.println("enter user id");
		int i=sc.nextInt();
		a.setUid(i);
		
		
		try {
			PreparedStatement ps=con.prepareStatement("insert into address(city,location,pin,uid) values(?,?,?,?)");
			ps.setString(1, a.getCity());
			ps.setString(2, a.getLocation());
			ps.setInt(3, a.getPin());
			ps.setInt(4, a.getUid());
			
			int status=ps.executeUpdate();
			if(status>0)
			{
				System.out.println("Address added successfully");
			}
			else
			{
				System.out.println("insertion got failed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void joininfo()
	{
		
	String query="select u.uid,u.name,u.mobile,u.email,a.city,a.location,a.pin from userdata u,address a where u.uid=a.uid";
	try {
		PreparedStatement p=con.prepareStatement(query);
		ResultSet rs=p.executeQuery();
		while(rs.next())
		{
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
			System.out.println(rs.getString(4));
			System.out.println(rs.getString(5));
			System.out.println(rs.getString(6));
			System.out.println(rs.getInt(7));
			
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	public static void main(String[] args) {
		RegisterUser u=new RegisterUser();
		int c=0;
		do {
			System.out.println("Welcome to Registration");
			System.out.println("press 1: For Registration");
			System.out.println("press 2:For Displaying All Record");
			System.out.println("press 3: For Searching A particular Record");
			System.out.println("press 4: For Update Record");
			System.out.println("press 5:For Delete Record");
			System.out.println("press 6: For Inserting Address Info");
			System.out.println("press 7:For Joining");
			Scanner sc= new Scanner(System.in);
			int n=sc.nextInt();
			switch(n)
			{
			case 1:
				u.adduser();
				break;
			case 2:
				u.showuser();
				break;
			case 3:
				u.searchuser();
				break;
			case 4:u.updatedata();
			break;
			case 5:
				u.deleteData();
				break;
			case 6:
				u.addressdata();
				break;
			case 7:
				u.joininfo();
				break;
				
			
				default:
			    break;
			}
			
			System.out.println("please enter 1 to continue:");
			c=sc.nextInt();
		} 
		while (c==1);
		System.out.println("Thank you!...");
	}
	
	}


