package Many_to_Many;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Storedataplayer {
	public static void main(String[] args) {
		Configuration config = new Configuration();
	    config.configure("hibernate.cfg.xml");
	    SessionFactory factory = config.buildSessionFactory();
	    Session session = factory.openSession();
	    Transaction t = session.beginTransaction();
	    Player p1=new Player();
	    p1.setName("cricket");
	    Player p2=new Player();
	    p1.setName("football");
	    Player p3=new Player();
	    p3.setName("Bascketball");
	    Sports s1=new Sports();
	    s1.setName("priya");
	    
	    
	    
	    
	}

}
