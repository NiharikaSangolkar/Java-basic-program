package Many_to_Many;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table (name="player_table")
public class Player {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	@ManyToMany(targetEntity = Sports.class, cascade = {CascadeType.ALL})
	@JoinTable(name="sports",joinColumns= {@JoinColumn(name="pid")},
	inverseJoinColumns= {@JoinColumn(name="sid")})
	private List<Sports> sports;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Sports> getSports() {
		return sports;
	}
	public void setSports(List<Sports> sports) {
		this.sports = sports;
	}
	
	

}
