package com.One_to_Many;
import javax.persistence.*;
@Entity
@Table (name="answer_table")
public class answer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String ans;
	private String postedBy;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public String getPostedBy() {
		return postedBy;
	}
	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}
	
	

}
