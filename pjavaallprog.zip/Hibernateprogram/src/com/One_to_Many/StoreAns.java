package com.One_to_Many;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreAns {
	public static void main(String[] args) {
		Configuration config = new Configuration();
	    config.configure("hibernate.cfg.xml");
	    SessionFactory factory = config.buildSessionFactory();
	    Session session = factory.openSession();
	    Transaction t = session.beginTransaction();
	    question q=new question();
	    q.setQue("what is oops?");
	    answer a1=new answer();
	    a1.setAns("oops is object oriented prog. langauage");
	    a1.setPostedBy("james");
	    answer a2=new answer();
	    a2.setAns("oops is paradigm");
	    a2.setPostedBy("peter");
	    answer a3=new answer();
	    a3.setAns("oops is modeling based prog lang");
	    a3.setPostedBy("priya");
	    ArrayList<answer>list=new ArrayList<>();
	    list.add(a1);
	    list.add(a2);
	    list.add(a3);
	    q.setAns(list);
	    session.persist(q);
	    t.commit();
	    session.close();
	    System.out.println("record saved");
	    
	    
	}

}
