package com.table_per_concrete;
import javax.persistence.*;
import javax.persistence.Entity;

@Entity
@Table(name="senior_faculty")
@AttributeOverrides({
	@AttributeOverride(name="id",column=@Column(name="teacher_id")),
	@AttributeOverride(name="name",column=@Column(name="name"))
	
})
public class Senior_Faculty extends Teacher{
	private float salary;
	private String subject;
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}

}
