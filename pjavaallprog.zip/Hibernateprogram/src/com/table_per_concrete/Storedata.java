package com.table_per_concrete;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

//import antlr.debug.GuessingEvent;



public class Storedata {
	public static void main(String[] args) {
		Configuration config = new Configuration();
	    config.configure("hibernate.cfg.xml");
	    SessionFactory factory = config.buildSessionFactory();
	    Session session = factory.openSession();
	    Transaction t = session.beginTransaction();
	    Teacher ts=new Teacher();
	    ts.setName("priya");
	    Senior_Faculty sf=new Senior_Faculty();
	    sf.setName("riya");
	    sf.setSalary(35000);
	    sf.setSubject("SQL");
	    GusetFaculty gf=new GusetFaculty();
	    gf.setName("sham");
	    gf.setPay_per_session(2400);
	    gf.setTokensession(10);
	    session.persist(ts);
	    session.persist(sf);
	    session.persist(gf);
	    t.commit();
	    session.close();
	    System.out.println("record saved ");
		
		
	}

}
