package com.table_per_concrete;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Guest_faculty")
@AttributeOverrides({
	@AttributeOverride(name="id",column=@Column(name="teacher_id")),
	@AttributeOverride(name="name",column=@Column(name="name"))
	
})

public class GusetFaculty extends Teacher {
	private float pay_per_session;
	private int tokensession;
	public float getPay_per_session() {
		return pay_per_session;
	}
	public void setPay_per_session(float pay_per_session) {
		this.pay_per_session = pay_per_session;
	}
	public int getTokensession() {
		return tokensession;
	}
	public void setTokensession(int tokensession) {
		this.tokensession = tokensession;
	}

}
