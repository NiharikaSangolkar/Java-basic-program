package com.basic;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class storeempdata {
	public static void main(String[] args) {
		{
			
			Configuration config = new Configuration();
			config.configure("hibernate.cfg.xml");
			SessionFactory factory = config.buildSessionFactory();
			Session session = factory.openSession();
			Transaction t = session.beginTransaction();
			
			Employee e = new Employee();
			
			e.setId(101);
			e.setFirstName("Rayaan");
			e.setLastName("joe");
			session.save(e);
			t.commit();
			System.out.println("Record Saved Sucessfully");
			factory.close();
			session.close();
			
		}
		
	}

}
