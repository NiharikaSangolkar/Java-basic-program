package com.basic;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class StroeStudent {
	
	public static void main(String[] args) {
		
	
	Configuration config = new Configuration();
     config.configure("hibernate.cfg.xml");
	SessionFactory factory = config.buildSessionFactory();
	Session session = factory.openSession();
	Transaction t = session.beginTransaction();
	
	
	Student s=new Student();
	
	s.setRoll_no(100);
	s.setName("Riya");
	s.setCoursename("Fullstack");
	
	session.save(s);
	t.commit();
	factory.close();
	session.close();

	

}
}