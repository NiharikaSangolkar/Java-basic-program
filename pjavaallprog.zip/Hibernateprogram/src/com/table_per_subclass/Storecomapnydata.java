package com.table_per_subclass;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Storecomapnydata {
	public static void main(String[] args) {
		Configuration config = new Configuration();
	    config.configure("hibernate.cfg.xml");
	    SessionFactory factory = config.buildSessionFactory();
	    Session session = factory.openSession();
	    Transaction t = session.beginTransaction();
	    person p=new person();
	    p.setName("priya");
	    Company_Employee e=new Company_Employee();
	    e.setName("vihaan");
	    e.setProject("E-commerce");
	    e.setSalary(45000);
	    Company_Clinent c=new Company_Clinent();
	    c.setName("Raviraj");
	    c.setAmount(4476879);
	    session.persist(p);
	    session.persist(c);
	    session.persist(e);
	    t.commit();
	    session.close();
	    System.out.println("record saved");
	}

}
