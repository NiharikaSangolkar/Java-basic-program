package com.table_per_subclass;
import javax.persistence.*;
@Entity
@Table(name="company_employee")
@PrimaryKeyJoinColumn(name="pid")
public class Company_Employee extends person{
	private String project;
	private float salary;
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	
}
