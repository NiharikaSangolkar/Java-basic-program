package com.table_per_heirarchy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreInformation {
public static void main(String[] args) {
	Configuration config = new Configuration();
    config.configure("hibernate.cfg.xml");
    SessionFactory factory = config.buildSessionFactory();
    Session session = factory.openSession();
    Transaction t = session.beginTransaction();
    
    
    EmployeeNew e=new EmployeeNew();
    e.setName("Sita");
    
    RegularEmployee r=new RegularEmployee();
    r.setBonus(5100);
    r.setSalary(28000);
    
    ContractEmployee c=new ContractEmployee();
    c.setDuration("18 Days");
    c.setPay_per_hour(2300);
    
    session.persist(e);
    session.persist(r);
    session.persist(c);
    
    t.commit();
    
    System.out.println("Records Save Successfully");
    factory.close();
    session.close();
}
}


