package com.one_to_one;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Storecustomer {
	public static void main(String[] args) {
		Configuration config = new Configuration();
	    config.configure("hibernate.cfg.xml");
	    SessionFactory factory = config.buildSessionFactory();
	    Session session = factory.openSession();
	    Transaction t = session.beginTransaction();
	    Customer c=new Customer();
	    c.setName("riya");
	    Address a=new Address();
	    a.setCity("pune");
	    a.setState("mh");
	    a.setPincode(411025);
	    c.setAddress(a);
	    a.setCustomer(c);
	    session.persist(c);
	    t.commit();
	    session.close();
	}

}
