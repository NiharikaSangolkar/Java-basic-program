package com.many_to_one;
import javax.persistence.*;
@Entity
@Table(name="college_coordinator")

public class Cooredinator {
	@Id

	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	@OneToOne(cascade = CascadeType.ALL)
	private college collegestudent;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public college getCollegestudent() {
		return collegestudent;
	}
	public void setCollegestudent(college collegestudent) {
		this.collegestudent = collegestudent;
	}
	

}
