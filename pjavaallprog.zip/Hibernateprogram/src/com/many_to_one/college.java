package com.many_to_one;
import javax.persistence.*;
@Entity
@Table(name="college_student")
public class college {
	@Id

	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	@ManyToOne(cascade = CascadeType.ALL)
	private  Cooredinator Cooredinator;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Cooredinator getCooredinator() {
		return Cooredinator;
	}
	public void setCooredinator(Cooredinator cooredinator) {
		Cooredinator = cooredinator;
	}

}
