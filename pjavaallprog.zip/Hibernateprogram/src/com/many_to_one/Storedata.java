package com.many_to_one;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Storedata {
	public static void main(String[] args) {
		Configuration config = new Configuration();
	    config.configure("hibernate.cfg.xml");
	    SessionFactory factory = config.buildSessionFactory();
	    Session session = factory.openSession();
	    Transaction t = session.beginTransaction();
	    college s1=new college();
	    s1.setName("anuja");
	    college s2=new college();
	    s1.setName("anu");
	    college s3=new college();
	    s1.setName("pooja");
	    Cooredinator c=new Cooredinator();
	    c.setName("Riya");
	    s1.setCooredinator(c);
	    s2.setCooredinator(c);
	    s3.setCooredinator(c);
	    session.persist(s1);
	    session.persist(s2);
	    session.persist(s3);
	    t.commit();
	    session.close();
	    System.out.println("record saved");
	    
	}

}
